import pandas as pd
import os
import requests
from concurrent.futures import ThreadPoolExecutor

def download_song_and_lyric(song_id, folder, fail_list):
    success = True
    song_link = f'http://music.163.com/song/media/outer/url?id={song_id}.mp3'
    lyric_link = f'http://music.163.com/api/song/lyric?os=pc&id={song_id}&lv=-1&kv=-1&tv=-1'
    song_path = os.path.join(folder, f'{song_id}.mp3')
    lyric_path = os.path.join(folder, f'{song_id}.txt')

    try:
        song_data = requests.get(song_link).content
        with open(song_path, 'wb') as song_file:
            song_file.write(song_data)
        print(f'歌曲ID"{song_id}"下载完成，保存至：{song_path}')
    except Exception as e:
        print(f'歌曲ID"{song_id}"下载出错：{e}')
        success = False

    try:
        response = requests.get(lyric_link).json()
        if 'lrc' in response and 'lyric' in response['lrc']:
            lyric = response['lrc']['lyric']
            with open(lyric_path, 'w', encoding='utf-8') as lyric_file:
                lyric_file.write(lyric)
            print(f'歌曲ID"{song_id}"的歌词下载完成，保存至：{lyric_path}')
        else:
            print(f'歌曲ID"{song_id}"的歌词未找到')
            success = False
    except Exception as e:
        print(f'歌曲ID"{song_id}"歌词下载出错：{e}')
        success = False

    if not success:
        fail_list.append(song_id)

def download_songs_and_lyrics(csv_path, download_folder):
    if not os.path.exists(download_folder):
        os.mkdir(download_folder)

    df = pd.read_csv(csv_path)
    fail_list = []

    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(download_song_and_lyric, row['id'], download_folder, fail_list) for index, row in df.iterrows()]
        for future in futures:
            future.result()

    # 如果有失败的下载，将它们保存到新的CSV文件中
    if fail_list:
        fail_df = df[df['id'].isin(fail_list)]
        fail_csv_path = os.path.join(download_folder, 'failed_downloads.csv')
        fail_df.to_csv(fail_csv_path, index=False)
        print(f'下载失败的记录已保存到 {fail_csv_path}')


if __name__ == '__main__':
    csv_file_path = "C:\\Users\shuoz\Desktop\\工作簿1.csv" # 更新为你的CSV文件路径
    download_folder ="C:\\Users\shuoz\Desktop\网易云"
    download_songs_and_lyrics(csv_file_path, download_folder)

