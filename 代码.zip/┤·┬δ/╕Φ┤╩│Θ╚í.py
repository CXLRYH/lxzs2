
import os
import shutil
import csv

# CSV文件路径
csv_file = "C:\\Users\shuoz\Desktop\网易云\music 2.csv"

# 原始文件夹路径
source_folder =  "D:\数量正确的网易云和歌词"

# 目标文件夹路径
target_folder = "C:\\Users\shuoz\Desktop\基于tensorflow实现声音分离源码资源包"

# 读取CSV文件
with open(csv_file, 'r') as file:
    reader = csv.reader(file)
    numbers = [row[0] for row in reader]  # 假设数字在第一列

# 遍历原始文件夹中的文件
for filename in os.listdir(source_folder):
    # 检查文件是否以'.txt'结尾
    if filename.endswith('.txt'):
        # 获取文件名（去除扩展名）
        file_number = os.path.splitext(filename)[0]

        # 检查文件名是否在CSV表格中的数字列表中
        if file_number in numbers:
            # 构建源文件和目标文件的完整路径
            source_path = os.path.join(source_folder, filename)
            target_path = os.path.join(target_folder, filename)

            # 复制文件到目标文件夹
            shutil.copy2(source_path, target_path)
            print(f"Copied: {filename}")

print("File copying completed.")