import pandas as pd
import os


def calculate_label_counts(csv_path, folder_path):
    # 读取CSV文件
    df = pd.read_csv(csv_path)

    # 创建id到label的映射字典
    id_label_dict = pd.Series(df.label.values, index=df.id.astype(str)).to_dict()

    # 创建存储每个label计数的字典
    label_counts_mp3 = {label: 0 for label in df['label'].unique()}
    label_counts_txt = {label: 0 for label in df['label'].unique()}

    # 预处理文件夹中的文件名，只保留.csv和.txt文件
    filtered_files = [file for file in os.listdir(folder_path) if file.endswith('.mp3') or file.endswith('.txt')]

    # 遍历过滤后的文件列表，更新匹配的label计数
    for file in filtered_files:
        file_id, extension = os.path.splitext(file)
        if file_id in id_label_dict:
            label = id_label_dict[file_id]
            if extension == '.mp3':
                label_counts_mp3[label] += 1
            elif extension == '.txt':
                label_counts_txt[label] += 1

    # 输出结果
    print("MP3 files label counts:")
    for label, count in label_counts_mp3.items():
        print(f"{label}: {count}")

    print("\nTXT files label counts:")
    for label, count in label_counts_txt.items():
        print(f"{label}: {count}")



if __name__ == '__main__':
    csv_path = "C:\\Users\shuoz\Desktop\网易云\output_table.csv"
    folder_path = "D:\数量正确的网易云和歌词"
    calculate_label_counts(csv_path, folder_path)
