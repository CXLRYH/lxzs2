import os
import shutil

# 源文件夹路径，假设所有的MP3文件都存储在这里
source_folder = "D:\数量正确的网易云和歌词"

# 目标文件夹路径，新文件夹将被创建在这些路径下
target_folder_1 = "D:\音乐文件1"
target_folder_2 = "D:\音乐文件2"

# 创建目标文件夹（如果它们不存在）
os.makedirs(target_folder_1, exist_ok=True)
os.makedirs(target_folder_2, exist_ok=True)

# 获取源文件夹中所有MP3文件的列表
mp3_files = [f for f in os.listdir(source_folder) if f.endswith('.mp3')]

# 检查确保有12000个MP3文件
assert len(mp3_files) == 12000, "The number of MP3 files is not 12000."

# 分割文件列表，前6000个文件移到第一个目标文件夹，其余移到第二个目标文件夹
for i, file in enumerate(mp3_files):
    if i < 6000:
        shutil.move(os.path.join(source_folder, file), os.path.join(target_folder_1, file))
    else:
        shutil.move(os.path.join(source_folder, file), os.path.join(target_folder_2, file))
