import pandas as pd

# 从CSV文件读取数据
df1 = pd.read_csv("C:\\Users\shuoz\Desktop\music 1.csv")  # 请将'path/to/your/df1.csv'替换为df1.csv文件的实际路径
df2 = pd.read_csv('C:\\Users\shuoz\Desktop\网易云\\validation.csv')  # 请将'path/to/your/df2.csv'替换为df2.csv文件的实际路径

# 根据df1中的id列，在df2中查找匹配的行并生成新的DataFrame
new_df = df2[df2['id'].isin(df1['id'])]

# 查看新生成的DataFrame
print(new_df)

# 如果需要，可以将新的DataFrame保存回CSV文件
new_df.to_csv('C:\\Users\shuoz\Desktop/new_df.csv', index=False)  # 请将'path/to/your/new_df.csv'替换为您希望保存的新CSV文件的路径
