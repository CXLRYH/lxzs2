import pandas as pd
import os


def compare_songs_and_lyrics(csv_path, folder_path, output_songs_path, output_lyrics_path):
    # 读取CSV文件中的歌曲ID
    df = pd.read_csv(csv_path)
    song_ids = set(df['id'].astype(str))  # 确保ID是字符串格式

    # 获取文件夹中所有文件的基本名（无扩展名）
    file_bases = {os.path.splitext(file)[0] for file in os.listdir(folder_path)}

    # 找出缺少MP3和歌词文件的歌曲ID
    missing_songs = song_ids - file_bases
    missing_lyrics = {song_id for song_id in song_ids if
                      not os.path.isfile(os.path.join(folder_path, f"{song_id}.txt"))}

    # 保存缺少的MP3文件的歌曲ID到CSV
    if missing_songs:
        print(f"发现 {len(missing_songs)} 首歌曲缺少对应的MP3文件，正在保存到 {output_songs_path}...")
        pd.DataFrame(list(missing_songs), columns=['Missing Song ID']).to_csv(output_songs_path, index=False)

    # 保存缺少的歌词文件的歌曲ID到CSV
    if missing_lyrics:
        print(f"发现 {len(missing_lyrics)} 首歌曲缺少对应的歌词文件，正在保存到 {output_lyrics_path}...")
        pd.DataFrame(list(missing_lyrics), columns=['Missing Lyric ID']).to_csv(output_lyrics_path, index=False)

    # 输出结果
    if not missing_songs and not missing_lyrics:
        print("所有歌曲ID在文件夹中都有对应的MP3和歌词文件。")
    else:
        print("缺少的MP3和歌词文件已分别保存。")


if __name__ == '__main__':
    csv_path = "C:\\Users\shuoz\Desktop\\1000数据.csv"  # 替换为您的CSV文件路径
    folder_path = "D:\网易云音乐与歌词" # 替换为您的音乐文件夹路径
    output_songs_path = 'C:\\Users\shuoz\Desktop\\6\missing_songs.csv'
    output_lyrics_path = 'C:\\Users\shuoz\Desktop\\6\missing_lyrics.csv'
    compare_songs_and_lyrics(csv_path, folder_path, output_songs_path, output_lyrics_path)
