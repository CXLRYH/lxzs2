import pandas as pd
import os


def delete_files_by_id(csv_path, folder_path, file_extensions=['.mp3', '.txt']):
    # 读取CSV文件中的id列
    df = pd.read_csv(csv_path)
    ids_to_delete = df['id'].astype(str).tolist()

    # 获取文件夹中所有文件
    files_in_folder = os.listdir(folder_path)

    # 初始化一个列表来记录被删除的文件
    deleted_files = []

    # 遍历id列表，对于每个id，检查并删除所有指定扩展名的文件
    for file_id in ids_to_delete:
        for extension in file_extensions:
            file_name = f"{file_id}{extension}"  # 构建文件名
            if file_name in files_in_folder:
                try:
                    os.remove(os.path.join(folder_path, file_name))
                    print(f"Deleted file: {file_name}")
                    deleted_files.append(file_name)
                except OSError as e:
                    print(f"Error: {e.strerror} - {file_name}")

    # 显示删除了哪些文件
    if deleted_files:
        print(f"Total deleted files: {len(deleted_files)}")
    else:
        print("No files were deleted.")


if __name__ == '__main__':
    csv_path = "C:\\Users\shuoz\Desktop\\failed_downloads.csv"  # CSV文件路径
    folder_path = "D:\网易云音乐与歌词" # 文件夹路径
    delete_files_by_id(csv_path, folder_path)
