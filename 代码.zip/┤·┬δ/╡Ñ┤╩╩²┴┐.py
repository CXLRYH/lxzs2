import re

def clean_text(text):
    # Remove LaTeX commands and environments
    text = re.sub(r'\\[a-zA-Z]+\{.*?\}', '', text)
    text = re.sub(r'\\[a-zA-Z]+', '', text)
    text = re.sub(r'\\[^a-zA-Z\s]', '', text)
    text = re.sub(r'\\label\{.*?\}', '', text)
    text = re.sub(r'\\[a-zA-Z]+\*', '', text)

    # Remove special characters
    text = re.sub(r'[^a-zA-Z\s]', ' ', text)

    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text)

    # Remove citation content
    text = re.sub(r'\\parencite\{.*?\}', '', text)
    text = re.sub(r'\\cite\{.*?\}', '', text)
    text = re.sub(r'\\textcite\{.*?\}', '', text)

    # Remove table content
    text = re.sub(r'\\begin\{table\}.*?\\end\{table\}', '', text, flags=re.DOTALL)

    return text.strip()

def count_words(text):
    words = text.split()
    return len(words)

# Load LaTeX file




# Load LaTeX file
with open("C:\\Users\shuoz\Desktop\Template for Journal of Computational Design and Engineering Manuscript Submissions (1)\main.tex", 'r', encoding='utf-8') as file:
    latex_content = file.read()

# Clean up LaTeX content
cleaned_text = clean_text(latex_content)

# Count words
word_count = count_words(cleaned_text)
print("Total number of words:", word_count)
