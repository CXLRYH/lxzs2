import matplotlib.pyplot as plt
import librosa
import librosa.display
import librosa.util
import numpy as np
import pysynth



# 要转换的输入wav音频文件
input_wav = "D:\音轨分离\1_64093_(Bass).wav"
# 要输出的音频文件
output_wav = "E:\音轨分离"
# 总共要输出的音符个数
number_notes = 30
# 音符时值1,2,4,8
note_time = 16
y, sr = librosa.load(input_wav, sr=None, duration=None)
cent = librosa.feature.spectral_centroid(y=y, sr=sr)





# 如果声音频率超过钢琴音域则升降八度直至落入钢琴音域为止
def frequency_limit(f):
    while f > 4186:
        f *= 0.5
    while f < 28:
        f *= 2
    return f





mod_r = cent[0].shape[0] % number_notes
cut_count = int(cent[0].shape[0] - mod_r)
merge_count = int(cut_count / number_notes)

c = cent[0][:cut_count].reshape(number_notes, merge_count)

frequencies = []
notes = []
for fs in c:
    fm = fs.mean()
    frequencies.append(fm)
    note = librosa.hz_to_note(fm, octave=True)
    notes.append(note.lower())

times = np.ones(len(notes)) * note_time
melody = tuple(zip(notes, times))
print(melody)

pysynth.make_wav(melody, fn=output_wav)

print("OK")



plt.subplot(211)
plt.plot(cent[0])
plt.xlabel('time')
plt.ylabel('frequency')
plt.subplot(212)
plt.scatter(range(len(frequencies)), frequencies)
plt.xlabel('time')
plt.ylabel('frequency')
