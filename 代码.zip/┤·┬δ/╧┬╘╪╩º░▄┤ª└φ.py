import pandas as pd


def remove_duplicates(csv_path1, csv_path2, output_path):
    # 读取两个CSV文件
    df1 = pd.read_csv(csv_path1)
    df2 = pd.read_csv(csv_path2)

    # 寻找两个DataFrame中重复的行
    # 假设重复的定义是两个DataFrame中所有列的值都相同
    duplicated_rows = pd.merge(df1, df2, how='inner')

    # 从df1中删除与df2重复的行
    # 这里使用merge的indicator参数，找到只在左侧（df1）中存在的行
    unique_df1 = pd.merge(df1, duplicated_rows, how='outer', indicator=True).loc[lambda x: x['_merge'] == 'left_only']
    unique_df1 = unique_df1.drop(columns=['_merge'])  # 删除辅助列

    # 将处理后的数据保存到新的CSV文件
    unique_df1.to_csv(output_path, index=False)
    print(f"已保存去重后的数据到 {output_path}")


if __name__ == '__main__':
    csv_path1 = "C:\\Users\shuoz\Desktop\网易云\\validation.csv"  # 第一个CSV文件路径
    csv_path2 = "C:\\Users\shuoz\Desktop\网易云\抽取项目.csv"  # 第二个CSV文件路径
    output_path = 'C:\\Users\shuoz\Desktop\网易云\/output_table.csv'  # 输出去重后的CSV文件路径
    remove_duplicates(csv_path1, csv_path2, output_path)