import os
import numpy as np
import librosa
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score, confusion_matrix
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler
from concurrent.futures import ThreadPoolExecutor
from torch.cuda.amp import autocast, GradScaler
from tqdm import tqdm
import torch.nn.functional as F
import math


# 位置编码
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=4000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:x.size(0), :]


# 数据准备
def load_data(data_dirs, csv_file, start_index, end_index, target_sr=16000):
    df = pd.read_csv(csv_file)

    fixed_features = []
    seq_features = []
    labels = []

    for data_dir in data_dirs:
        # 根据文件名生成字典
        file_dict = {}
        for sub_dir in ['vocals', 'drums', 'bass', 'other']:
            sub_dir_path = os.path.join(data_dir, sub_dir)
            file_list = os.listdir(sub_dir_path)
            for file_name in file_list:
                if file_name.endswith(".wav"):
                    music_id = int(file_name[:-4])
                    if music_id not in file_dict:
                        file_dict[music_id] = {}
                    file_dict[music_id][sub_dir] = file_name

        # 匹配 CSV 文件中的标签
        for music_id, file_names in tqdm(list(file_dict.items())[start_index:end_index], desc="Extracting features"):
            label = df.loc[df['id'] == music_id, 'label'].values
            if len(label) > 0:
                label = label[0]
                fixed_feature_group = {}  # 用字典存储每个音源类型的固定特征
                seq_feature_group = {}  # 用字典存储每个音源类型的连续特征
                for sub_dir in ['vocals', 'drums', 'bass', 'other']:
                    file_path = os.path.join(data_dir, sub_dir, file_names[sub_dir])
                    waveform, sr = librosa.load(file_path, sr=target_sr)

                    # 提取特征
                    pitches, magnitudes = librosa.piptrack(y=waveform, sr=sr)
                    pitch = np.mean(pitches)  # 平均音高
                    loudness = np.mean(librosa.amplitude_to_db(magnitudes))  # 响度
                    pitch_changes = np.mean(np.diff(pitches))  # 音高变化
                    tuning = librosa.estimate_tuning(y=waveform, sr=sr)  # 调性
                    key = tuning  # 以Hz为单位表示的调性

                    fixed_feature_group[sub_dir] = np.array([pitch, loudness, pitch_changes, key])

                    mfcc = librosa.feature.mfcc(y=waveform, sr=sr, n_mfcc=13)  # MFCC
                    rolloff = librosa.feature.spectral_rolloff(y=waveform, sr=sr)  # 声谱滚降点
                    chroma = librosa.feature.chroma_stft(y=waveform, sr=sr)  # 色度频率

                    # 确保连续特征具有相同的形状
                    max_seq_length = 4000  # 设定最大连续特征长度
                    if mfcc.shape[1] > max_seq_length:
                        mfcc = mfcc[:, :max_seq_length]
                        rolloff = rolloff[:, :max_seq_length]
                        chroma = chroma[:, :max_seq_length]
                    else:
                        pad_width = ((0, 0), (0, max_seq_length - mfcc.shape[1]))
                        mfcc = np.pad(mfcc, pad_width, mode='constant')
                        rolloff = np.pad(rolloff, pad_width, mode='constant')
                        chroma = np.pad(chroma, pad_width, mode='constant')

                    seq_feature_group[sub_dir] = np.concatenate([mfcc, rolloff, chroma], axis=0)

                fixed_features.append(fixed_feature_group)
                seq_features.append(seq_feature_group)
                labels.append(label)
            else:
                print(f"Label not found for music_id: {music_id}")

    return fixed_features, seq_features, labels


# 模型定义
class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size):
        super(ConvBlock, self).__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, padding='same')
        self.bn = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class TransformerBlock(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward):
        super(TransformerBlock, self).__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)
        self.relu = nn.ReLU()
        self.layer_norm1 = nn.LayerNorm(d_model)
        self.layer_norm2 = nn.LayerNorm(d_model)

    def forward(self, x):
        x2 = self.self_attn(x, x, x)[0]
        x = x + x2
        x = self.layer_norm1(x)
        x2 = self.linear2(self.relu(self.linear1(x)))
        x = x + x2
        x = self.layer_norm2(x)
        return x


class EmotionClassifier(nn.Module):
    def __init__(self, fixed_dim, seq_dim, num_emotions, name):
        super(EmotionClassifier, self).__init__()
        self.name = name

        self.vocals_conv = nn.Sequential(
            ConvBlock(seq_dim, 64, 3),
            ConvBlock(64, 128, 3)
        )
        self.drums_conv = nn.Sequential(
            ConvBlock(seq_dim, 64, 3),
            ConvBlock(64, 128, 3)
        )
        self.bass_conv = nn.Sequential(
            ConvBlock(seq_dim, 64, 3),
            ConvBlock(64, 128, 3)
        )
        self.other_conv = nn.Sequential(
            ConvBlock(seq_dim, 64, 3),
            ConvBlock(64, 128, 3)
        )

        self.pos_encoder = PositionalEncoding(128)  # 添加位置编码

        self.vocals_transformer = TransformerBlock(128, 4, 256)
        self.drums_transformer = TransformerBlock(128, 4, 256)
        self.bass_transformer = TransformerBlock(128, 4, 256)
        self.other_transformer = TransformerBlock(128, 4, 256)

        self.fixed_vocals_dense = nn.Linear(fixed_dim, 32)
        self.fixed_drums_dense = nn.Linear(fixed_dim, 32)
        self.fixed_bass_dense = nn.Linear(fixed_dim, 32)
        self.fixed_other_dense = nn.Linear(fixed_dim, 32)

        self.fusion = nn.Linear(128 * 4 + 32 * 4, 256)
        self.dense1 = nn.Linear(256, 128)
        self.dense2 = nn.Linear(128, num_emotions)

    def forward(self, fixed_dict, seq_dict):
        vocals_seq = seq_dict['vocals']  # (batch_size, feature_dim, time_steps)
        drums_seq = seq_dict['drums']
        bass_seq = seq_dict['bass']
        other_seq = seq_dict['other']

        vocals_seq = self.vocals_conv(vocals_seq)
        drums_seq = self.drums_conv(drums_seq)
        bass_seq = self.bass_conv(bass_seq)
        other_seq = self.other_conv(other_seq)

        vocals_seq = vocals_seq.transpose(1, 2)  # (batch_size, time_steps, feature_dim)
        drums_seq = drums_seq.transpose(1, 2)
        bass_seq = bass_seq.transpose(1, 2)
        other_seq = other_seq.transpose(1, 2)

        vocals_seq = self.pos_encoder(vocals_seq)  # 添加位置编码
        drums_seq = self.pos_encoder(drums_seq)
        bass_seq = self.pos_encoder(bass_seq)
        other_seq = self.pos_encoder(other_seq)

        vocals_seq = self.vocals_transformer(vocals_seq)
        drums_seq = self.drums_transformer(drums_seq)
        bass_seq = self.bass_transformer(bass_seq)
        other_seq = self.other_transformer(other_seq)

        vocals_seq = vocals_seq.mean(dim=1)
        drums_seq = drums_seq.mean(dim=1)
        bass_seq = bass_seq.mean(dim=1)
        other_seq = other_seq.mean(dim=1)

        vocals_fixed = self.fixed_vocals_dense(fixed_dict['vocals'])
        drums_fixed = self.fixed_drums_dense(fixed_dict['drums'])
        bass_fixed = self.fixed_bass_dense(fixed_dict['bass'])
        other_fixed = self.fixed_other_dense(fixed_dict['other'])

        x = torch.cat([vocals_seq, drums_seq, bass_seq, other_seq,
                       vocals_fixed, drums_fixed, bass_fixed, other_fixed], dim=-1)
        x = self.fusion(x)
        x = self.dense1(x)
        x = self.dense2(x)
        return x


# 模型训练
def train_model(model, train_loader, test_loader, epochs, device, emotion_labels, accumulation_steps=16, step=0,
                continuous_learning_steps=1000):
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters())
    scaler = GradScaler()
    best_accuracy = 0.0

    model_dir = "models"
    os.makedirs(model_dir, exist_ok=True)  # 创建目录,如果目录不存在

    model = model.to(device)

    metrics_list = []  # 用于存储评估指标的列表

    for epoch in range(epochs):
        model.train()
        for batch_idx, (fixed_dict, seq_dict, target) in enumerate(train_loader):
            fixed_dict = {k: v.to(device) for k, v in fixed_dict.items()}
            seq_dict = {k: v.to(device) for k, v in seq_dict.items()}
            target = target.to(device)
            optimizer.zero_grad()

            with autocast():
                output = model(fixed_dict, seq_dict)
                loss = criterion(output, target)
                loss = loss / accumulation_steps  # 将损失除以累积步数

            scaler.scale(loss).backward()

            if (batch_idx + 1) % accumulation_steps == 0:
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

        model.eval()
        with torch.no_grad():
            all_predictions = []
            all_targets = []
            for fixed_dict, seq_dict, target in test_loader:
                fixed_dict = {k: v.to(device) for k, v in fixed_dict.items()}
                seq_dict = {k: v.to(device) for k, v in seq_dict.items()}
                target = target.to(device)
                with autocast():
                    output = model(fixed_dict, seq_dict)
                predicted = torch.sigmoid(output)
                _, predicted_indices = torch.max(predicted, dim=1)
                all_predictions.append(predicted_indices.cpu().numpy())
                all_targets.append(target.cpu().numpy())

            all_predictions = np.concatenate(all_predictions)
            all_targets = np.argmax(np.concatenate(all_targets), axis=1)

            # 计算混淆矩阵
            conf_matrix = confusion_matrix(all_targets, all_predictions)
            print(conf_matrix)
            # 从混淆矩阵计算F1、recall和precision
            f1 = f1_score(all_targets, all_predictions, average='micro')
            recall = recall_score(all_targets, all_predictions, average='micro')
            precision = precision_score(all_targets, all_predictions, average='micro')

            print(
                f"Continuous Learning Step {step + 1}/{continuous_learning_steps}, Epoch {epoch + 1}/{epochs}, Test F1 Score: {f1:.4f}, Recall: {recall:.4f}, Precision: {precision:.4f}")

            # 计算每种情绪的F1、recall和precision
            f1_per_class = f1_score(all_targets, all_predictions, average=None)
            recall_per_class = recall_score(all_targets, all_predictions, average=None)
            precision_per_class = precision_score(all_targets, all_predictions, average=None)

            for emotion_idx, emotion_label in enumerate(emotion_labels):
                if emotion_idx < len(f1_per_class):
                    print(
                        f"Emotion {emotion_label}: F1 Score: {f1_per_class[emotion_idx]:.4f}, Recall: {recall_per_class[emotion_idx]:.4f}, Precision: {precision_per_class[emotion_idx]:.4f}")
                else:
                    print(f"Emotion {emotion_label}: Not enough samples to calculate metrics.")

            accuracy = accuracy_score(all_targets, all_predictions)
            emotion_accuracies = []
            for emotion_idx in range(len(emotion_labels)):
                emotion_targets = all_targets == emotion_idx
                emotion_predictions = all_predictions == emotion_idx
                emotion_accuracy = accuracy_score(emotion_targets, emotion_predictions)
                emotion_accuracies.append(emotion_accuracy)
                print(f"Emotion{emotion_labels[emotion_idx]}: Accuracy: {emotion_accuracy:.4f}")

            metrics = {
                'Continuous Learning Step': step + 1,
                'Epoch': epoch + 1,
                'Accuracy': accuracy,
                'F1 Score': f1,
                'Recall': recall,
                'Precision': precision
            }
            for emotion_idx, emotion_label in enumerate(emotion_labels):
                metrics[f'{emotion_label} Accuracy'] = emotion_accuracies[emotion_idx]

            metrics_list.append(metrics)  # 将当前 epoch 的评估指标添加到列表中

            if accuracy > best_accuracy:
                best_accuracy = accuracy
                model_path = os.path.join(model_dir, f"{model.name}.pth")
                torch.save(model.state_dict(), model_path)

    print(f"Best Test Accuracy: {best_accuracy:.4f}")

    metrics_df = pd.DataFrame(metrics_list)  # 将评估指标列表转换为 DataFrame
    print("\nTraining Metrics:")
    print(metrics_df)

    return metrics_df

def collate_fn(batch):
    fixed_dict = {
        'vocals': [],
        'drums': [],
        'bass': [],
        'other': []
    }
    seq_dict = {
        'vocals': [],
        'drums': [],
        'bass': [],
        'other': []
    }
    targets = []

    for sample in batch:
        fixed_features = sample[:4]
        seq_features = sample[4:8]
        label = sample[-1]

        for sub_dir, fixed_feature in zip(['vocals', 'drums', 'bass', 'other'], fixed_features):
            fixed_dict[sub_dir].append(fixed_feature.numpy())

        for sub_dir, seq_feature in zip(['vocals', 'drums', 'bass', 'other'], seq_features):
            seq_dict[sub_dir].append(seq_feature.numpy())

        targets.append(label.numpy())

    # 设定最大连续特征长度
    max_seq_length = 4000

    for sub_dir in ['vocals', 'drums', 'bass', 'other']:
        # 对固定特征进行填充
        fixed_dict[sub_dir] = torch.tensor(fixed_dict[sub_dir], dtype=torch.float32)

        # 对连续特征进行剪切或填充
        seq_features = []
        for seq_feature in seq_dict[sub_dir]:
            if seq_feature.shape[1] > max_seq_length:
                # 如果超过最大长度,进行剪切
                seq_feature = seq_feature[:, :max_seq_length]
            else:
                # 如果不足最大长度,进行填充
                pad_width = ((0, 0), (0, max_seq_length - seq_feature.shape[1]))
                seq_feature = np.pad(seq_feature, pad_width, mode='constant')
            seq_features.append(seq_feature)

        seq_dict[sub_dir] = torch.tensor(seq_features, dtype=torch.float32)

    targets = torch.tensor(targets, dtype=torch.float32)

    return fixed_dict, seq_dict, targets

def count_music_groups(data_dir):
    music_ids = set()
    for sub_dir in ['vocals', 'drums', 'bass', 'other']:
        sub_dir_path = os.path.join(data_dir, sub_dir)
        file_list = os.listdir(sub_dir_path)
        for file_name in file_list:
            if file_name.endswith(".wav"):
                music_id = int(file_name[:-4])
                music_ids.add(music_id)
    return len(music_ids)

if __name__ == '__main__':
    data_dirs = ['C:/音轨1', 'D:/BaiduNetdiskDownload/音轨2']  # 修改为包含两个目录的列表
    csv_file = 'D:/validation.csv'
    emotion_labels = ['Melancholic', 'Fresh', 'Healing', 'Peaceful', 'Exciting', 'Joyful', 'Romantic', 'Nostalgic',
                      'Lonely', 'Relaxing', 'Touching', 'Missing']
    num_emotions = len(emotion_labels)
    num_threads = 384
    epochs = 100
    continuous_learning_steps = 1
    target_sr = 16000
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    total_groups = sum(count_music_groups(data_dir) for data_dir in data_dirs)  # 计算所有目录中的总文件数量
    batch_size = total_groups // continuous_learning_steps  # 根据总文件数量和连续学习步数计算每次读取的数量

    all_metrics_df = pd.DataFrame()  # 用于存储所有连续学习步骤的指标

    for step in range(continuous_learning_steps):
        print(f"Continuous Learning Step {step + 1}/{continuous_learning_steps}")

        start_index = step * batch_size
        end_index = (step + 1) * batch_size if step < continuous_learning_steps - 1 else total_groups

        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            print(f"Using {num_threads} threads for data loading.")

            futures = []
            chunk_size = (end_index - start_index) // num_threads
            for i in range(num_threads):
                sub_start_index = start_index + i * chunk_size
                sub_end_index = start_index + (i + 1) * chunk_size if i < num_threads - 1 else end_index
                futures.append(
                    executor.submit(load_data, data_dirs, csv_file, sub_start_index, sub_end_index, target_sr))

            fixed_features = []
            seq_features = []
            labels = []
            for future in futures:
                fixed_features_batch, seq_features_batch, labels_batch = future.result()
                fixed_features.extend(fixed_features_batch)
                seq_features.extend(seq_features_batch)
                labels.extend(labels_batch)

        print("Data loading completed.")
        # 将情绪标签转换为独热编码形式
        num_samples = len(labels)
        one_hot_labels = np.zeros((num_samples, num_emotions))
        for i, label in enumerate(labels):
            one_hot_labels[i, emotion_labels.index(label)] = 1

        # 使用分层采样进行数据集划分
        train_fixed_features, test_fixed_features, train_seq_features, test_seq_features, train_labels, test_labels = train_test_split(
            fixed_features, seq_features, one_hot_labels, test_size=0.2, stratify=labels, random_state=42)

        print("Data split completed. Starting model training...")

        # 将固定特征和连续特征转换为张量
        train_fixed_features_tensors = {
            sub_dir: torch.tensor([fixed_feature[sub_dir] for fixed_feature in train_fixed_features], dtype=torch.float32)
            for sub_dir in ['vocals', 'drums', 'bass', 'other']
        }
        train_seq_features_tensors = {
            sub_dir: torch.tensor([seq_feature[sub_dir] for seq_feature in train_seq_features], dtype=torch.float32)
            for sub_dir in ['vocals', 'drums', 'bass', 'other']
        }

        test_fixed_features_tensors = {
            sub_dir: torch.tensor([fixed_feature[sub_dir] for fixed_feature in test_fixed_features], dtype=torch.float32)
            for sub_dir in ['vocals', 'drums', 'bass', 'other']
        }
        test_seq_features_tensors = {
            sub_dir: torch.tensor([seq_feature[sub_dir] for seq_feature in test_seq_features], dtype=torch.float32)
            for sub_dir in ['vocals', 'drums', 'bass', 'other']
        }

        # 计算每个情感类别的权重
        emotion_counts = train_labels.sum(axis=0)
        weights = 1.0 / emotion_counts
        sample_weights = weights[train_labels.argmax(axis=1)]

        # 创建加权随机采样器
        sampler = WeightedRandomSampler(sample_weights, len(sample_weights))

        train_dataset = TensorDataset(train_fixed_features_tensors['vocals'], train_fixed_features_tensors['drums'],
                                      train_fixed_features_tensors['bass'], train_fixed_features_tensors['other'],
                                      train_seq_features_tensors['vocals'], train_seq_features_tensors['drums'],
                                      train_seq_features_tensors['bass'], train_seq_features_tensors['other'],
                                      torch.from_numpy(train_labels).float())
        train_loader = DataLoader(train_dataset, batch_size=16, sampler=sampler, collate_fn=collate_fn)

        test_dataset = TensorDataset(test_fixed_features_tensors['vocals'], test_fixed_features_tensors['drums'],
                                     test_fixed_features_tensors['bass'], test_fixed_features_tensors['other'],
                                     test_seq_features_tensors['vocals'], test_seq_features_tensors['drums'],
                                     test_seq_features_tensors['bass'], test_seq_features_tensors['other'],
                                     torch.from_numpy(test_labels).float())
        test_loader = DataLoader(test_dataset, batch_size=16, collate_fn=collate_fn)

        fixed_dim = train_fixed_features_tensors['vocals'].shape[1]  # 获取固定特征的维度
        seq_dim = train_seq_features_tensors['vocals'].shape[1]  # 获取连续特征的维度

        if step == 0:
            model = EmotionClassifier(fixed_dim, seq_dim, num_emotions, name='EmotionClassifier').to(device)
        else:
            model = EmotionClassifier(fixed_dim, seq_dim, num_emotions, name='EmotionClassifier').to(device)
            model.load_state_dict(torch.load('models/EmotionClassifier.pth'))

        # 训练模型并获取指标
        step_metrics_df = train_model(model, train_loader, test_loader, epochs, device, emotion_labels,
                                      accumulation_steps=8, step=step,
                                      continuous_learning_steps=continuous_learning_steps)

        # 将当前步骤的指标添加到总表格中
        all_metrics_df = pd.concat([all_metrics_df, step_metrics_df], ignore_index=True)

    # 将总表格保存为 CSV 文件
    all_metrics_df.to_csv(f"{model.name}_training_metrics.csv", index=False)

