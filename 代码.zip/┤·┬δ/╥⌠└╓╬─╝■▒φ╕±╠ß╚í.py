import os
import pandas as pd

# 定义一个函数来遍历文件夹并提取所有.wav格式的文件名
def extract_wav_filenames(folder_path):
    wav_filenames = []
    # 遍历文件夹
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.mp3'):
                # 去除文件扩展名，只保留文件名
                filename_without_extension = os.path.splitext(file)[0]
                wav_filenames.append(filename_without_extension)
    return wav_filenames

# 文件夹路径（需要根据实际情况修改）
folder_path = "D:\音乐文件2"

# 提取.wav文件名
wav_filenames = extract_wav_filenames(folder_path)

# 创建DataFrame
df = pd.DataFrame(wav_filenames, columns=['Filename'])

# 保存到Excel文件，如果需要其他格式（如CSV），可以使用to_csv
df.to_csv('music 2.csv', index=False)

print('文件名表格已生成并保存为 wav_filenames.csv')



