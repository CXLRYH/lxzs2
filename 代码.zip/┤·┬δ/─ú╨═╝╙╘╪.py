import os
import torch
import torch.nn as nn
import librosa
import numpy as np
from transformers import BertTokenizer, BertModel
from sklearn.preprocessing import StandardScaler, LabelEncoder
from collections import defaultdict


class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(ResidualBlock, self).__init__()

        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm1d(out_channels)

        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=1, stride=stride),
                nn.BatchNorm1d(out_channels)
            )
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        out += self.shortcut(residual)
        out = self.relu(out)

        return out


class ConvVAEEncoder(nn.Module):
    def __init__(self, input_dim, latent_dim):
        super(ConvVAEEncoder, self).__init__()
        self.conv_layers = nn.Sequential(
            nn.Conv1d(input_dim, 128, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv1d(128, 256, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv1d(256, 512, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            ResidualBlock(512, 512),
            ResidualBlock(512, 512),
        )

        self.fc_layers = nn.Sequential(
            nn.Linear(512 * 32, 2048),
            nn.ReLU(),
            nn.Linear(2048, 1024),
            nn.ReLU(),
            nn.Linear(1024, latent_dim * 2)
        )

    def forward(self, x):
        x = self.conv_layers(x)
        x = x.view(x.size(0), -1)
        x = self.fc_layers(x)
        latent_dim = x.size(1) // 2
        mean = x[:, :latent_dim]
        log_std = x[:, latent_dim:]
        std = torch.exp(0.5 * log_std)
        return mean, std


class ConvVAEDecoder(nn.Module):
    def __init__(self, latent_dim, output_dim):
        super(ConvVAEDecoder, self).__init__()

        self.fc_layers = nn.Sequential(
            nn.Linear(latent_dim, 1024),
            nn.ReLU(),
            nn.Linear(1024, 2048),
            nn.ReLU(),
            nn.Linear(2048, 512 * 32),
            nn.ReLU()
        )

        self.deconv_layers = nn.Sequential(
            ResidualBlock(512, 512),
            ResidualBlock(512, 512),
            nn.ConvTranspose1d(512, 256, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.ReLU(),
            nn.ConvTranspose1d(256, 128, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.ReLU(),
            nn.ConvTranspose1d(128, output_dim, kernel_size=3, stride=1, padding=1),
            nn.Tanh()
        )

    def forward(self, x):
        x = self.fc_layers(x)
        x = x.view(x.size(0), 512, 32)
        x = self.deconv_layers(x)
        return x


class VAE(nn.Module):
    def __init__(self, input_dim, latent_dim):
        super(VAE, self).__init__()
        self.input_dim = input_dim
        self.encoder = ConvVAEEncoder(input_dim, latent_dim)
        self.decoder = ConvVAEDecoder(latent_dim, input_dim)

    def forward(self, x):
        mean, std = self.encoder(x)
        z = self.reparameterize(mean, std)
        recon_x = self.decoder(z)
        return recon_x, z, mean, std

    def reparameterize(self, mean, std):
        eps = torch.randn_like(std)
        return eps.mul(std).add_(mean)


class LyricsEncoder(nn.Module):
    def __init__(self, hidden_dim=256):
        super(LyricsEncoder, self).__init__()
        self.bert = BertModel.from_pretrained('bert-base-uncased')
        self.fc = nn.Linear(self.bert.config.hidden_size, hidden_dim)

    def forward(self, encoded_input):
        outputs = self.bert(**encoded_input)
        pooled_output = outputs.pooler_output
        lyrics_embeddings = self.fc(pooled_output)
        return lyrics_embeddings


class EmotionClassifier(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(EmotionClassifier, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, 12)  # Output 12 emotion confidence scores

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x


def load_audio_file(file_path, sample_rate=16000):
    audio, _ = librosa.load(file_path, sr=sample_rate, mono=True)
    return audio


def extract_audio_features(audio, n_fft=512, hop_length=256, n_mels=128):
    mel_spectrogram = librosa.feature.melspectrogram(y=audio, sr=16000, n_fft=n_fft, hop_length=hop_length,
                                                     n_mels=n_mels)
    log_mel_spectrogram = librosa.power_to_db(mel_spectrogram, ref=np.max)
    mfccs = librosa.feature.mfcc(S=log_mel_spectrogram, n_mfcc=20)
    features = np.concatenate((log_mel_spectrogram, mfccs), axis=0)
    return features


def adjust_feature_shape(features, target_shape):
    current_shape = features.shape
    if current_shape[0] == target_shape[0]:
        if current_shape[1] < target_shape[1]:
            padding = np.zeros((current_shape[0], target_shape[1] - current_shape[1]))
            features = np.concatenate((features, padding), axis=1)
        elif current_shape[1] > target_shape[1]:
            features = features[:, :target_shape[1]]
    else:
        raise ValueError(f"Input feature shape {current_shape} does not match the expected shape {target_shape}")
    return features


class AudioEmotionAnalyzer:
    def __init__(self, model_path, device='cuda'):
        self.device = device
        self.load_model(model_path)
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.scaler = StandardScaler()
        self.emotion_labels = ['Melancholic', 'Fresh', 'Healing', 'Peaceful', 'Exciting', 'Joyful', 'Romantic',
                               'Nostalgic', 'Lonely', 'Relaxing', 'Touching', 'Missing']
        self.label_encoder = LabelEncoder().fit(self.emotion_labels)

    def load_model(self, model_path):
        self.vae_models = {
            music_type: VAE(input_dim, latent_dims[music_type]).to(self.device)
            for music_type, latent_dim in latent_dims.items()
        }
        self.lyrics_encoder = LyricsEncoder().to(self.device)
        self.emotion_classifier = EmotionClassifier(sum(latent_dims.values()) + 256, 512).to(self.device)

        checkpoint = torch.load(model_path, map_location=self.device)
        for music_type, vae in self.vae_models.items():
            vae.load_state_dict(checkpoint[f'vae_{music_type}'])
        self.lyrics_encoder.load_state_dict(checkpoint['lyrics_encoder'])
        self.emotion_classifier.load_state_dict(checkpoint['emotion_classifier'])
        self.scaler.mean_ = checkpoint['scaler_mean']
        self.scaler.scale_ = checkpoint['scaler_scale']

    def analyze_emotion(self, audio_files, lyrics):
        audio_features = self.extract_audio_features(audio_files)
        encoded_input = self.tokenizer(lyrics, return_tensors='pt', max_length=128, padding='max_length',
                                       truncation=True).to(self.device)

        with torch.no_grad():
            recon_data = {}
            z = {}
            for music_type, vae in self.vae_models.items():
                recon_data[music_type], z[music_type], _, _ = vae(audio_features[music_type])

            lyrics_embeddings = self.lyrics_encoder(encoded_input)
            combined_embeddings = torch.cat([z[t] for t in z] + [lyrics_embeddings], dim=1)
            emotion_logits = self.emotion_classifier(combined_embeddings)

        emotion_probs = torch.softmax(emotion_logits, dim=1).cpu().numpy()[0]
        emotion_scores = dict(zip(self.emotion_labels, emotion_probs))
        return emotion_scores

    def extract_audio_features(self, audio_files):
        audio_features = {}
        for music_type in ['vocals', 'bass', 'other', 'drums']:
            if f'{music_type}.wav' in audio_files:
                audio, _ = librosa.load(audio_files[f'{music_type}.wav'], sr=16000, mono=True)
                features = extract_audio_features(audio)
                features = adjust_feature_shape(features, target_shape=(input_dim, 7119))
                features = self.scaler.transform(features.T).T.astype(np.float16)
                audio_features[music_type] = torch.from_numpy(features).float().to(self.device).unsqueeze(0)
        return audio_features

    def generate_music(self, target_emotion, audio_files):
        audio_features = self.extract_audio_features(audio_files)

        with torch.no_grad():
            original_z = {
                music_type: self.vae_models[music_type].encoder(audio_features[music_type])[0]
                for music_type in audio_features
            }

        target_logits = torch.zeros(1, len(self.emotion_labels), device=self.device)
        target_logits[0, self.label_encoder.transform([target_emotion])[0]] = 1.0

        modified_z = optimize_latent_representations(original_z, self.vae_models, self.lyrics_encoder,
                                                     self.emotion_classifier, target_logits)

        generated_audio = {}
        for music_type in modified_z:
            generated_audio[f'{music_type}.wav'] = \
            self.vae_models[music_type].decoder(modified_z[music_type]).cpu().numpy()[0]

        return generated_audio


def optimize_latent_representations(original_z, vae_models, lyrics_encoder, emotion_classifier, target_logits, lr=0.1,
                                    num_steps=1000):
    modified_z = {
        music_type: original_z[music_type].clone().detach().requires_grad_(True)
        for music_type in original_z
    }

    optimizer = torch.optim.Adam(modified_z.values(), lr=lr)

    for step in range(num_steps):
        optimizer.zero_grad()

        recon_data = {}
        z = {}
        for music_type, vae in vae_models.items():
            recon_data[music_type], z[music_type], _, _ = vae(modified_z[music_type])

        lyrics_embeddings = torch.zeros(1, 256, device=target_logits.device)
        combined_embeddings = torch.cat([z[t] for t in z] + [lyrics_embeddings], dim=1)
        emotion_logits = emotion_classifier(combined_embeddings)

        loss = torch.mean((emotion_logits - target_logits) ** 2)
        loss.backward()
        optimizer.step()

    return {music_type: modified_z[music_type].detach() for music_type in modified_z}


if __name__ == '__main__':
    input_dim = 148
    latent_dims = {
        'vocals': 64,
        'bass': 32,
        'other': 48,
        'drums': 32
    }

    analyzer = AudioEmotionAnalyzer('path/to/model.pth')

    # 分析情感
    audio_files = {
        'vocals.wav': 'path/to/vocals.wav',
        'bass.wav': 'path/to/bass.wav',
        'other.wav': 'path/to/other.wav',
        'drums.wav': 'path/to/drums.wav'
    }
    lyrics = "Lyrics text..."
    emotion_scores = analyzer.analyze_emotion(audio_files, lyrics)
    print("Original emotion scores:")
    print(emotion_scores)

    # 修改情感置信度
    modified_scores = {}
    for emotion in analyzer.emotion_labels:
        score = float(input(f"请输入{emotion}的新置信度分数(0-1): "))
        modified_scores[emotion] = score

    # 生成新音乐
    target_emotion = 'Joyful'
    generated_audio = analyzer.generate_music(target_emotion, audio_files)
    for music_type, audio in generated_audio.items():
        librosa.output.write_wav(f'generated_{music_type}.wav', audio, sr=16000)