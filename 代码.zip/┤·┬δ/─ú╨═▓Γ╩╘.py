import os
import numpy as np
import librosa
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score, confusion_matrix
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler
from concurrent.futures import ThreadPoolExecutor
from torch.cuda.amp import autocast, GradScaler
from tqdm import tqdm
import torch.nn.functional as F
import math


# 位置编码
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=4000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:x.size(0), :]


# 数据准备
def load_data(data_dirs, csv_file, start_index, end_index, target_sr=16000):
    df = pd.read_csv(csv_file)

    fixed_features = []
    seq_features = []
    labels = []

    for data_dir in data_dirs:
        # 根据文件名生成字典
        file_dict = {}
        for sub_dir in ['vocals', 'drums', 'bass', 'other']:
            sub_dir_path = os.path.join(data_dir, sub_dir)
            file_list = os.listdir(sub_dir_path)
            for file_name in file_list:
                if file_name.endswith(".wav"):
                    music_id = int(file_name[:-4])
                    if music_id not in file_dict:
                        file_dict[music_id] = {}
                    file_dict[music_id][sub_dir] = file_name

        # 匹配 CSV 文件中的标签
        for music_id, file_names in tqdm(list(file_dict.items())[start_index:end_index], desc="Extracting features"):
            label = df.loc[df['id'] == music_id, 'label'].values
            if len(label) > 0:
                label = label[0]
                fixed_feature_group = {}  # 用字典存储每个音源类型的固定特征
                seq_feature_group = {}  # 用字典存储每个音源类型的连续特征
                for sub_dir in ['vocals', 'drums', 'bass', 'other']:
                    file_path = os.path.join(data_dir, sub_dir, file_names[sub_dir])
                    waveform, sr = librosa.load(file_path, sr=target_sr)

                    # 提取特征
                    pitches, magnitudes = librosa.piptrack(y=waveform, sr=sr)
                    pitch = np.mean(pitches)  # 平均音高
                    loudness = np.mean(librosa.amplitude_to_db(magnitudes))  # 响度
                    pitch_changes = np.mean(np.diff(pitches))  # 音高变化
                    tuning = librosa.estimate_tuning(y=waveform, sr=sr)  # 调性
                    key = tuning  # 以Hz为单位表示的调性

                    fixed_feature_group[sub_dir] = np.array([pitch, loudness, pitch_changes, key])

                    mfcc = librosa.feature.mfcc(y=waveform, sr=sr, n_mfcc=13)  # MFCC
                    rolloff = librosa.feature.spectral_rolloff(y=waveform, sr=sr)  # 声谱滚降点
                    chroma = librosa.feature.chroma_stft(y=waveform, sr=sr)  # 色度频率

                    # 确保连续特征具有相同的形状
                    max_seq_length = 4000  # 设定最大连续特征长度
                    if mfcc.shape[1] > max_seq_length:
                        mfcc = mfcc[:, :max_seq_length]
                        rolloff = rolloff[:, :max_seq_length]
                        chroma = chroma[:, :max_seq_length]
                    else:
                        pad_width = ((0, 0), (0, max_seq_length - mfcc.shape[1]))
                        mfcc = np.pad(mfcc, pad_width, mode='constant')
                        rolloff = np.pad(rolloff, pad_width, mode='constant')
                        chroma = np.pad(chroma, pad_width, mode='constant')

                    seq_feature_group[sub_dir] = np.concatenate([mfcc, rolloff, chroma], axis=0)

                fixed_features.append(fixed_feature_group)
                seq_features.append(seq_feature_group)
                labels.append(label)
            else:
                print(f"Label not found for music_id: {music_id}")

    return fixed_features, seq_features, labels


# 模型定义
class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size):
        super(ConvBlock, self).__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, padding='same')
        self.bn = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class TransformerBlock(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward):
        super(TransformerBlock, self).__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)
        self.relu = nn.ReLU()
        self.layer_norm1 = nn.LayerNorm(d_model)
        self.layer_norm2 = nn.LayerNorm(d_model)

    def forward(self, x):
        x2 = self.self_attn(x, x, x)[0]
        x = x + x2
        x = self.layer_norm1(x)
        x2 = self.linear2(self.relu(self.linear1(x)))
        x = x + x2
        x = self.layer_norm2(x)
        return x


class EmotionClassifier(nn.Module):
    def __init__(self, fixed_dim, seq_dim, num_emotions, name):
        super(EmotionClassifier, self).__init__()
        self.name = name

        self.vocals_conv = nn.Sequential(
            ConvBlock(seq_dim, 64, 3),
            ConvBlock(64, 128, 3)
        )
        self.drums_conv = nn.Sequential(
            ConvBlock(seq_dim, 64, 3),
            ConvBlock(64, 128, 3)
        )
        self.bass_conv = nn.Sequential(
            ConvBlock(seq_dim, 64, 3),
            ConvBlock(64, 128, 3)
        )
        self.other_conv = nn.Sequential(
            ConvBlock(seq_dim, 64, 3),
            ConvBlock(64, 128, 3)
        )

        self.pos_encoder = PositionalEncoding(128)  # 添加位置编码

        self.vocals_transformer = TransformerBlock(128, 4, 256)
        self.drums_transformer = TransformerBlock(128, 4, 256)
        self.bass_transformer = TransformerBlock(128, 4, 256)
        self.other_transformer = TransformerBlock(128, 4, 256)

        self.fixed_vocals_dense = nn.Linear(fixed_dim, 32)
        self.fixed_drums_dense = nn.Linear(fixed_dim, 32)
        self.fixed_bass_dense = nn.Linear(fixed_dim, 32)
        self.fixed_other_dense = nn.Linear(fixed_dim, 32)

        self.fusion = nn.Linear(128 * 4 + 32 * 4, 256)
        self.dense1 = nn.Linear(256, 128)
        self.dense2 = nn.Linear(128, num_emotions)

    def forward(self, fixed_dict, seq_dict):
        vocals_seq = seq_dict['vocals']  # (batch_size, feature_dim, time_steps)
        drums_seq = seq_dict['drums']
        bass_seq = seq_dict['bass']
        other_seq = seq_dict['other']

        vocals_seq = self.vocals_conv(vocals_seq)
        drums_seq = self.drums_conv(drums_seq)
        bass_seq = self.bass_conv(bass_seq)
        other_seq = self.other_conv(other_seq)

        vocals_seq = vocals_seq.transpose(1, 2)  # (batch_size, time_steps, feature_dim)
        drums_seq = drums_seq.transpose(1, 2)
        bass_seq = bass_seq.transpose(1, 2)
        other_seq = other_seq.transpose(1, 2)

        vocals_seq = self.pos_encoder(vocals_seq)  # 添加位置编码
        drums_seq = self.pos_encoder(drums_seq)
        bass_seq = self.pos_encoder(bass_seq)
        other_seq = self.pos_encoder(other_seq)

        vocals_seq = self.vocals_transformer(vocals_seq)
        drums_seq = self.drums_transformer(drums_seq)
        bass_seq = self.bass_transformer(bass_seq)
        other_seq = self.other_transformer(other_seq)

        vocals_seq = vocals_seq.mean(dim=1)
        drums_seq = drums_seq.mean(dim=1)
        bass_seq = bass_seq.mean(dim=1)
        other_seq = other_seq.mean(dim=1)

        vocals_fixed = self.fixed_vocals_dense(fixed_dict['vocals'])
        drums_fixed = self.fixed_drums_dense(fixed_dict['drums'])
        bass_fixed = self.fixed_bass_dense(fixed_dict['bass'])
        other_fixed = self.fixed_other_dense(fixed_dict['other'])

        x = torch.cat([vocals_seq, drums_seq, bass_seq, other_seq,
                       vocals_fixed, drums_fixed, bass_fixed, other_fixed], dim=-1)
        x = self.fusion(x)
        x = self.dense1(x)
        x = self.dense2(x)
        return x


# 模型训练
def train_model(model, train_loader, test_loader, epochs, device, emotion_labels, accumulation_steps=16, step=0,
                continuous_learning_steps=1000):
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters())
    scaler = GradScaler()
    best_accuracy = 0.0

    model_dir = "models"
    os.makedirs(model_dir, exist_ok=True)  # 创建目录,如果目录不存在

    model = model.to(device)

    metrics_list = []  # 用于存储评估指标的列表

    for epoch in range(epochs):
        model.train()
        for batch_idx, (fixed_dict, seq_dict, target) in enumerate(train_loader):
            fixed_dict = {k: v.to(device) for k, v in fixed_dict.items()}
            seq_dict = {k: v.to(device) for k, v in seq_dict.items()}
            target = target.to(device)
            optimizer.zero_grad()

            with autocast():
                output = model(fixed_dict, seq_dict)
                loss = criterion(output, target)
                loss = loss / accumulation_steps  # 将损失除以累积步数

            scaler.scale(loss).backward()

            if (batch_idx + 1) % accumulation_steps == 0:
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

        model.eval()
        with torch.no_grad():
            all_predictions = []
            all_targets = []
            for fixed_dict, seq_dict, target in test_loader:
                fixed_dict = {k: v.to(device) for k, v in fixed_dict.items()}
                seq_dict = {k: v.to(device) for k, v in seq_dict.items()}
                target = target.to(device)
                with autocast():
                    output = model(fixed_dict, seq_dict)
                predicted = torch.sigmoid(output)
                _, predicted_indices = torch.max(predicted, dim=1)
                all_predictions.append(predicted_indices.cpu().numpy())
                all_targets.append(target.cpu().numpy())

            all_predictions = np.concatenate(all_predictions)
            all_targets = np.argmax(np.concatenate(all_targets), axis=1)

            # 计算混淆矩阵
            conf_matrix = confusion_matrix(all_targets, all_predictions)

            # 从混淆矩阵计算F1、recall和precision
            f1 = f1_score(all_targets, all_predictions, average='micro')
            recall = recall_score(all_targets, all_predictions, average='micro')
            precision = precision_score(all_targets, all_predictions, average='micro')

            print(
                f"Continuous Learning Step {step + 1}/{continuous_learning_steps}, Epoch {epoch + 1}/{epochs}, Test F1 Score: {f1:.4f}, Recall: {recall:.4f}, Precision: {precision:.4f}")

            # 计算每种情绪的F1、recall和precision
            f1_per_class = f1_score(all_targets, all_predictions, average=None)
            recall_per_class = recall_score(all_targets, all_predictions, average=None)
            precision_per_class = precision_score(all_targets, all_predictions, average=None)

            for emotion_idx, emotion_label in enumerate(emotion_labels):
                if emotion_idx < len(f1_per_class):
                    print(
                        f"Emotion {emotion_label}: F1 Score: {f1_per_class[emotion_idx]:.4f}, Recall: {recall_per_class[emotion_idx]:.4f}, Precision: {precision_per_class[emotion_idx]:.4f}")
                else:
                    print(f"Emotion {emotion_label}: Not enough samples to calculate metrics.")

            accuracy = accuracy_score(all_targets, all_predictions)
            emotion_accuracies = []
            for emotion_idx in range(len(emotion_labels)):
                emotion_targets = all_targets == emotion_idx
                emotion_predictions = all_predictions == emotion_idx
                emotion_accuracy = accuracy_score(emotion_targets, emotion_predictions)
                emotion_accuracies.append(emotion_accuracy)
                print(f"Emotion{emotion_labels[emotion_idx]}: Accuracy: {emotion_accuracy:.4f}")

            metrics = {
                'Continuous Learning Step': step + 1,
                'Epoch': epoch + 1,
                'Accuracy': accuracy,
                'F1 Score': f1,
                'Recall': recall,
                'Precision': precision
            }
            for emotion_idx, emotion_label in enumerate(emotion_labels):
                metrics[f'{emotion_label} Accuracy'] = emotion_accuracies[emotion_idx]

            metrics_list.append(metrics)  # 将当前 epoch 的评估指标添加到列表中

            if accuracy > best_accuracy:
                best_accuracy = accuracy
                model_path = os.path.join(model_dir, f"{model.name}.pth")
                torch.save(model.state_dict(), model_path)

    print(f"Best Test Accuracy: {best_accuracy:.4f}")

    metrics_df = pd.DataFrame(metrics_list)  # 将评估指标列表转换为 DataFrame
    print("\nTraining Metrics:")
    print(metrics_df)

    return metrics_df

def collate_fn(batch):
    fixed_dict = {
        'vocals': [],
        'drums': [],
        'bass': [],
        'other': []
    }
    seq_dict = {
        'vocals': [],
        'drums': [],
        'bass': [],
        'other': []
    }
    targets = []

    for sample in batch:
        fixed_features = sample[:4]
        seq_features = sample[4:8]
        label = sample[-1]

        for sub_dir, fixed_feature in zip(['vocals', 'drums', 'bass', 'other'], fixed_features):
            fixed_dict[sub_dir].append(fixed_feature.numpy())

        for sub_dir, seq_feature in zip(['vocals', 'drums', 'bass', 'other'], seq_features):
            seq_dict[sub_dir].append(seq_feature.numpy())

        targets.append(label.numpy())

    # 设定最大连续特征长度
    max_seq_length = 4000

    for sub_dir in ['vocals', 'drums', 'bass', 'other']:
        # 对固定特征进行填充
        fixed_dict[sub_dir] = torch.tensor(fixed_dict[sub_dir], dtype=torch.float32)

        # 对连续特征进行剪切或填充
        seq_features = []
        for seq_feature in seq_dict[sub_dir]:
            if seq_feature.shape[1] > max_seq_length:
                # 如果超过最大长度,进行剪切
                seq_feature = seq_feature[:, :max_seq_length]
            else:
                # 如果不足最大长度,进行填充
                pad_width = ((0, 0), (0, max_seq_length - seq_feature.shape[1]))
                seq_feature = np.pad(seq_feature, pad_width, mode='constant')
            seq_features.append(seq_feature)

        seq_dict[sub_dir] = torch.tensor(seq_features, dtype=torch.float32)

    targets = torch.tensor(targets, dtype=torch.float32)

    return fixed_dict, seq_dict, targets

def count_music_groups(data_dir):
    music_ids = set()
    for sub_dir in ['vocals', 'drums', 'bass', 'other']:
        sub_dir_path = os.path.join(data_dir, sub_dir)
        file_list = os.listdir(sub_dir_path)
        for file_name in file_list:
            if file_name.endswith(".wav"):
                music_id = int(file_name[:-4])
                music_ids.add(music_id)
    return len(music_ids)

# 加载模型
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
original_num_emotions = 12  # 原始模型的情感类别数量
fixed_dim=4
seq_dim=26
model = EmotionClassifier(fixed_dim, seq_dim, original_num_emotions, name='EmotionClassifier').to(device)
model_path = os.path.join('models', 'EmotionClassifier.pth')
model.load_state_dict(torch.load(model_path))
model.eval()

# 加载新数据集
new_data_dirs = ['C:\\Users\cw102\Desktop\测试集']
new_csv_file = 'C:\\Users\cw102\Desktop\\final_emotions.csv'
new_fixed_features, new_seq_features, new_labels = load_data(new_data_dirs, new_csv_file, 0, None, target_sr=16000)
# 获取特征维度
fixed_dim = new_fixed_features[0]['vocals'].shape[0]
seq_dim = new_seq_features[0]['vocals'].shape[0]

# 重新实例化模型
model = EmotionClassifier(fixed_dim, seq_dim, original_num_emotions, name='EmotionClassifier').to(device)
model.load_state_dict(torch.load(model_path))

# 映射新的情感类别
original_emotion_labels = ['Melancholic', 'Fresh', 'Healing', 'Peaceful', 'Exciting', 'Joyful', 'Romantic', 'Nostalgic',
                           'Lonely', 'Relaxing', 'Touching', 'Missing']
new_emotion_labels = ['amazement', 'solemnity', 'tenderness', 'nostalgia', 'calmness', 'power', 'joyful_activation', 'tension', 'sadness']
emotion_mapping = {
    'amazement': ['Joyful', 'Exciting'],
    'solemnity': ['Healing', 'Peaceful'],
    'tenderness': ['Romantic', 'Touching'],
    'nostalgia': ['Nostalgic', 'Melancholic'],
    'calmness': ['Peaceful', 'Relaxing'],
    'power': ['Exciting'],
    'joyful_activation': ['Joyful', 'Exciting'],
    'tension': ['Exciting', 'Lonely'],
    'sadness': ['Melancholic', 'Lonely']
}
# 对新数据集进行预处理
num_samples = len(new_labels)
one_hot_labels = np.zeros((num_samples, original_num_emotions))
for i, label in enumerate(new_labels):
    if label in emotion_mapping:
        mapped_emotions = emotion_mapping[label]
        for mapped_emotion in mapped_emotions:
            one_hot_labels[i, original_emotion_labels.index(mapped_emotion)] = 1
    else:
        # 如果无法映射,则标记为"其他"类别
        one_hot_labels[i, original_emotion_labels.index('Missing')] = 1

new_fixed_features_tensors = {
    sub_dir: torch.tensor([fixed_feature[sub_dir] for fixed_feature in new_fixed_features], dtype=torch.float32)
    for sub_dir in ['vocals', 'drums', 'bass', 'other']
}
new_seq_features_tensors = {
    sub_dir: torch.tensor([seq_feature[sub_dir] for seq_feature in new_seq_features], dtype=torch.float32)
    for sub_dir in ['vocals', 'drums', 'bass', 'other']
}

new_dataset = TensorDataset(new_fixed_features_tensors['vocals'], new_fixed_features_tensors['drums'],
                            new_fixed_features_tensors['bass'], new_fixed_features_tensors['other'],
                            new_seq_features_tensors['vocals'], new_seq_features_tensors['drums'],
                            new_seq_features_tensors['bass'], new_seq_features_tensors['other'],
                            torch.from_numpy(one_hot_labels).float())
new_loader = DataLoader(new_dataset, batch_size=128, collate_fn=collate_fn)

# 在新数据集上进行测试
all_predictions = []
all_targets = []
with torch.no_grad():
    for fixed_dict, seq_dict, target in new_loader:
        fixed_dict = {k: v.to(device) for k, v in fixed_dict.items()}
        seq_dict = {k: v.to(device) for k, v in seq_dict.items()}
        target = target.to(device)
        with autocast():
            output = model(fixed_dict, seq_dict)
        predicted_scores = torch.sigmoid(output)  # 获取每个情感类别的分数
        _, predicted_indices = torch.max(predicted_scores, dim=1)  # 选择分数最高的情感类别作为预测结果
        all_predictions.append(predicted_indices.cpu().numpy())
        all_targets.append(target.cpu().numpy())

all_predictions = np.concatenate(all_predictions)
all_targets = np.argmax(np.concatenate(all_targets), axis=1)

# 计算评估指标
conf_matrix = confusion_matrix(all_targets, all_predictions)
f1 = f1_score(all_targets, all_predictions, average='micro')
recall = recall_score(all_targets, all_predictions, average='micro')
precision = precision_score(all_targets, all_predictions, average='micro')
accuracy = accuracy_score(all_targets, all_predictions)

print(f"Test F1 Score: {f1:.4f}, Recall: {recall:.4f}, Precision: {precision:.4f}, Accuracy: {accuracy:.4f}")

# 计算每种情绪的指标
mapped_prediction_indices = []
mapped_target_indices = []
for emotion_idx, emotion_label in enumerate(new_emotion_labels):
    if emotion_label in emotion_mapping:
        mapped_emotions = emotion_mapping[emotion_label]
        mapped_indices = [original_emotion_labels.index(mapped_emotion) for mapped_emotion in mapped_emotions]
        mapped_prediction_indices.extend([emotion_idx] * np.sum(all_predictions == emotion_idx))
        mapped_target_indices.extend([idx for idx in mapped_indices for _ in range(np.sum(all_targets == emotion_idx))])

# 确保mapped_prediction_indices和mapped_target_indices的长度相同
max_length = max(len(mapped_prediction_indices), len(mapped_target_indices))
mapped_prediction_indices = np.array(mapped_prediction_indices + [-1] * (max_length - len(mapped_prediction_indices)))
mapped_target_indices = np.array(mapped_target_indices + [-1] * (max_length - len(mapped_target_indices)))

# 删除无效索引(-1)
valid_indices = (mapped_prediction_indices != -1) & (mapped_target_indices != -1)
mapped_prediction_indices = mapped_prediction_indices[valid_indices]
mapped_target_indices = mapped_target_indices[valid_indices]

f1_per_class = f1_score(mapped_target_indices, mapped_prediction_indices, average=None,
                        labels=list(range(len(new_emotion_labels))))
recall_per_class = recall_score(mapped_target_indices, mapped_prediction_indices, average=None,
                                labels=list(range(len(new_emotion_labels))))
precision_per_class = precision_score(mapped_target_indices, mapped_prediction_indices, average=None,
                                      labels=list(range(len(new_emotion_labels))))

# 计算每个类别的正确预测数量
correct_predictions_per_class = np.zeros(len(new_emotion_labels), dtype=int)
for pred, target in zip(mapped_prediction_indices, mapped_target_indices):
    if pred == target:
        correct_predictions_per_class[pred] += 1

for emotion_idx, emotion_label in enumerate(new_emotion_labels):
    if emotion_label in emotion_mapping:
        mapped_emotions = emotion_mapping[emotion_label]
        mapped_indices = [original_emotion_labels.index(mapped_emotion) for mapped_emotion in mapped_emotions]
        f1_scores = [f1_per_class[emotion_idx] for idx in mapped_indices]
        recall_scores = [recall_per_class[emotion_idx] for idx in mapped_indices]
        precision_scores = [precision_per_class[emotion_idx] for idx in mapped_indices]
        accuracy_scores = [
            correct_predictions_per_class[emotion_idx] / np.sum(mapped_target_indices == emotion_idx) if np.sum(
                mapped_target_indices == emotion_idx) > 0 else 0 for idx in mapped_indices]  # 计算每个映射情感类别的准确率
        print(
            f"Emotion {emotion_label}: F1 Scores: {', '.join(f'{score:.4f}' for score in f1_scores)}, Recall Scores: {', '.join(f'{score:.4f}' for score in recall_scores)}, Precision Scores: {', '.join(f'{score:.4f}' for score in precision_scores)}, Accuracy Scores: {', '.join(f'{score:.4f}' for score in accuracy_scores)}")
    else:
        print(f"Emotion {emotion_label}: Not enough samples to calculate metrics.")