import pandas as pd


def sample_by_label(csv_path, output_path, sample_size=1000):
    # 读取CSV文件
    df = pd.read_csv(csv_path)

    # 移除`id`列中的重复项
    df = df.drop_duplicates(subset='id')

    # 按`label`分组，并从每个组中随机抽取样本
    sampled_df = df.groupby('label', group_keys=False).apply(lambda x: x.sample(min(len(x), sample_size)))

    # 保存结果到新的CSV文件
    sampled_df.to_csv(output_path, index=False)
    print(f"已保存抽样结果到 {output_path}")


if __name__ == '__main__':
    csv_path = "C:\\Users\shuoz\Desktop\网易云\\validation.csv"  # 替换为您的CSV文件路径
    output_path = "C:\\Users\shuoz\Desktop\网易云\\validation.csv"  # 输出抽样结果的文件路径
    sample_by_label(csv_path, output_path)