import os
import numpy as np
import librosa
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score, confusion_matrix
from sklearn.utils import resample
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from concurrent.futures import ThreadPoolExecutor
from torch.cuda.amp import autocast, GradScaler
from tqdm import tqdm


class ReplayBuffer:
    def __init__(self, max_size):
        self.max_size = max_size
        self.buffer = []

    def add(self, fixed_features, sequence_features, labels):
        if len(self.buffer) >= self.max_size:
            self.buffer.pop(0)
        self.buffer.append((fixed_features, sequence_features, labels))

    def sample(self, batch_size):
        if len(self.buffer) < batch_size:
            return None
        indices = np.random.choice(len(self.buffer), batch_size, replace=False)
        fixed_features, sequence_features, labels = zip(*[self.buffer[i] for i in indices])
        return list(fixed_features), list(sequence_features), list(labels)


# 自定义Dataset类
class MyDataset(Dataset):
    def __init__(self, fixed_features, sequence_features, labels):
        self.fixed_features = fixed_features
        self.sequence_features = sequence_features
        self.labels = labels

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        fixed_features = torch.tensor(self.fixed_features[idx]).float().view(-1, 4)

        sequence_features = [
            (torch.from_numpy(mfcc).float(), torch.from_numpy(rolloff).float(), torch.from_numpy(chroma).float())
            for mfcc, rolloff, chroma in self.sequence_features[idx]
        ]
        label = self.labels[idx]

        return fixed_features, sequence_features, label


# 数据准备
def load_data(data_dir, csv_file, start_index, end_index, target_sr=160000, target_samples_per_class=1000,
              max_seq_length=4000):
    df = pd.read_csv(csv_file)

    # 根据文件名生成字典
    file_dict = {}
    for sub_dir in ['vocals', 'drums', 'bass', 'other']:
        sub_dir_path = os.path.join(data_dir, sub_dir)
        file_list = os.listdir(sub_dir_path)
        for file_name in file_list:
            if file_name.endswith(".wav"):
                music_id = int(file_name[:-4])
                if music_id not in file_dict:
                    file_dict[music_id] = {'vocals': None, 'drums': None, 'bass': None, 'other': None}
                file_dict[music_id][sub_dir] = file_name

    # 匹配 CSV 文件中的标签
    fixed_features = []
    sequence_features = []
    labels = []
    emotion_samples = {emotion: [] for emotion in emotion_labels}
    for music_id in tqdm(list(file_dict.keys())[start_index:end_index], desc="Extracting features"):
        label = df.loc[df['id'] == music_id, 'label'].values
        if len(label) > 0:
            label = label[0]
            file_names = file_dict[music_id]
            fixed_feature_values = []
            sequence_feature_groups = []
            for sub_dir in ['vocals', 'drums', 'bass', 'other']:
                if file_names[sub_dir] is not None:
                    file_path = os.path.join(data_dir, sub_dir, file_names[sub_dir])
                    waveform, sr = librosa.load(file_path, sr=target_sr)

                    # 提取特征
                    pitches, magnitudes = librosa.piptrack(y=waveform, sr=sr)
                    pitch = np.mean(pitches)  # 平均音高
                    loudness = np.mean(librosa.amplitude_to_db(magnitudes))  # 响度
                    pitch_changes = np.mean(np.diff(pitches))  # 音高变化
                    tuning = librosa.estimate_tuning(y=waveform, sr=sr)  # 调性
                    key = tuning  # 以Hz为单位表示的调性

                    # 固定属性特征
                    fixed_feature_values.extend([pitch, loudness, pitch_changes, key])

                    # 序列特征
                    mfcc = librosa.feature.mfcc(y=waveform, sr=sr, n_mfcc=10)
                    rolloff = librosa.feature.spectral_rolloff(y=waveform, sr=sr)  # 声谱滚降点
                    chroma = librosa.feature.chroma_stft(y=waveform, sr=16000)  # 色度频率

                    # 对时间维度进行截断或填充,使得所有特征数组的时间长度一致
                    pad_width_mfcc = max(0, max_seq_length - mfcc.shape[1])
                    pad_width_rolloff = max(0, max_seq_length - rolloff.shape[1])
                    pad_width_chroma = max(0, max_seq_length - chroma.shape[1])

                    mfcc_padded = np.pad(mfcc, ((0, 0), (0, pad_width_mfcc)), 'constant')[:, :max_seq_length]
                    rolloff_padded = np.pad(rolloff, ((0, 0), (0, pad_width_rolloff)), 'constant')[:, :max_seq_length]
                    chroma_padded = np.pad(chroma, ((0, 0), (0, pad_width_chroma)), 'constant')[:, :max_seq_length]

                    sequence_feature_groups.append((mfcc_padded, rolloff_padded, chroma_padded))

            if len(fixed_feature_values) == 16:
                fixed_features.append(fixed_feature_values)
                sequence_features.append(sequence_feature_groups)
                labels.append(label)
                emotion_samples[label].append((fixed_feature_values, sequence_feature_groups))
        else:
            print(f"Label not found for music_id: {music_id}")

    # 对每个情绪类别进行随机抽样
    for emotion, samples in emotion_samples.items():
        if len(samples) > target_samples_per_class:
            samples = resample(samples, n_samples=target_samples_per_class, random_state=42)
        for sample in samples:
            fixed_features.append(sample[0])
            sequence_features.append(sample[1])
            labels.append(emotion)

    return fixed_features, sequence_features, labels


def collate_fn(batch):
    fixed_features, sequence_features, labels = zip(*batch)

    # 填充固定特征
    fixed_features = [torch.stack(feat_group) for feat_group in zip(*fixed_features)]

    # 填充序列特征
    padded_sequence_features = []
    for seq_feat_groups in zip(*sequence_features):
        seq_feat_group_padded = []
        for seq_feat_group in zip(*seq_feat_groups):
            if len(seq_feat_group) == 3:  # 如果有三个序列特征
                mfcc_features = [feat[0] for feat in seq_feat_group]
                rolloff_features = [feat[1] for feat in seq_feat_group]
                chroma_features = [feat[2] for feat in seq_feat_group]

                mfcc_features = torch.nn.utils.rnn.pad_sequence(mfcc_features, batch_first=True)
                rolloff_features = torch.nn.utils.rnn.pad_sequence(rolloff_features, batch_first=True)
                chroma_features = torch.nn.utils.rnn.pad_sequence(chroma_features, batch_first=True)

                seq_feat_group_padded.append((mfcc_features, rolloff_features, chroma_features))
            else:  # 如果序列特征长度不等于3,则使用全零张量
                seq_feat_group_padded.append(
                    (torch.zeros(1, 10, 4000), torch.zeros(1, 1, 4000), torch.zeros(1, 12, 4000)))

        padded_sequence_features.append(seq_feat_group_padded)

    labels = torch.tensor(labels, dtype=torch.long)  # 将labels转换为Tensor,并使用long()转换为整数类型

    return fixed_features, padded_sequence_features, labels


# 模型定义
class MultiModalAttentionModel(nn.Module):
    def __init__(self, fixed_dim, num_emotions, name):
        super(MultiModalAttentionModel, self).__init__()
        self.name = name

        # 固定属性分支
        self.fixed_dense1 = nn.Linear(fixed_dim, 64)
        self.fixed_dense2 = nn.Linear(64, 32)

        # 序列特征分支
        self.mfcc_lstm = nn.LSTM(10, 64, batch_first=True, bidirectional=True)
        self.rolloff_lstm = nn.LSTM(1, 64, batch_first=True, bidirectional=True)
        self.chroma_lstm = nn.LSTM(12, 64, batch_first=True, bidirectional=True)

        # 注意力机制
        self.fixed_attention = nn.Sequential(
            nn.Linear(32, 16),
            nn.Tanh(),
            nn.Linear(16, 1),
            nn.Softmax(dim=1)
        )
        self.mfcc_attention = nn.Sequential(
            nn.Linear(128, 64),
            nn.Tanh(),
            nn.Linear(64, 1),
            nn.Softmax(dim=1)
        )
        self.rolloff_attention = nn.Sequential(
            nn.Linear(128, 64),
            nn.Tanh(),
            nn.Linear(64, 1),
            nn.Softmax(dim=1)
        )
        self.chroma_attention = nn.Sequential(
            nn.Linear(128, 64),
            nn.Tanh(),
            nn.Linear(64, 1),
            nn.Softmax(dim=1)
        )

        # 融合层
        self.dropout = nn.Dropout(p=0.8)
        self.dense1 = nn.Linear(1664, 128)  # 确保输入维度为1664
        self.dense2 = nn.Linear(128, 64)
        self.output = nn.Linear(64, num_emotions)

    def forward(self, fixed_x, seq_x):
        outputs = []
        for i in range(len(fixed_x)):
            fixed_outs = []
            for j, fixed_feat in enumerate(fixed_x[i]):
                fixed_feat = fixed_feat.unsqueeze(0)  # 在第一个维度上添加批次维度
                fixed_out = torch.relu(self.fixed_dense1(fixed_feat))
                fixed_out = torch.relu(self.fixed_dense2(fixed_out))
                fixed_attention_weights = self.fixed_attention(fixed_out)
                fixed_out = torch.sum(fixed_attention_weights * fixed_out, dim=1)
                fixed_out = fixed_out.unsqueeze(1)  # 确保固定特征输出至少有两个维度
                fixed_outs.append(fixed_out)

            seq_outs = []
            for seq_feat in seq_x[i]:
                mfcc_features, rolloff_features, chroma_features = seq_feat

                # 对mfcc_features进行转置,使其形状符合LSTM的输入要求
                mfcc_features = mfcc_features.transpose(1, 2)
                mfcc_out, _ = self.mfcc_lstm(mfcc_features)
                mfcc_attention_weights = self.mfcc_attention(mfcc_out)
                mfcc_out = torch.sum(mfcc_attention_weights * mfcc_out, dim=1)

                # 对rolloff_features进行转置和unsqueeze操作,使其形状符合LSTM的输入要求
                rolloff_features = rolloff_features.transpose(1, 2)
                rolloff_out, _ = self.rolloff_lstm(rolloff_features)
                rolloff_attention_weights = self.rolloff_attention(rolloff_out)
                rolloff_out = torch.sum(rolloff_attention_weights * rolloff_out, dim=1)

                # 对chroma_features进行转置,使其形状符合LSTM的输入要求
                chroma_features = chroma_features.transpose(1, 2)
                chroma_out, _ = self.chroma_lstm(chroma_features)
                chroma_attention_weights = self.chroma_attention(chroma_out)
                chroma_out = torch.sum(chroma_attention_weights * chroma_out, dim=1)

                # 检查并调整张量的维度
                if mfcc_out.dim() == 1:
                    mfcc_out = mfcc_out.unsqueeze(1)
                if rolloff_out.dim() == 1:
                    rolloff_out = rolloff_out.unsqueeze(1)
                if chroma_out.dim() == 1:
                    chroma_out = chroma_out.unsqueeze(1)

                seq_out = torch.cat((mfcc_out, rolloff_out, chroma_out), dim=1)
                seq_outs.append(seq_out)

            fixed_out = torch.cat(fixed_outs, dim=1)
            seq_out = torch.cat(seq_outs, dim=1)
            x = torch.cat((fixed_out, seq_out), dim=1)

            # 调整x的维度为(batch_size, 1664)
            x = x.view(x.size(0), -1)
            if x.size(1) < 1664:
                padding = torch.zeros(x.size(0), 1664 - x.size(1)).to(x.device)
                x = torch.cat((x, padding), dim=1)

            outputs.append(x)

        x = torch.stack(outputs, dim=0)  # 将批次维度放在第一维
        x = self.dropout(x)
        x = torch.relu(self.dense1(x))
        x = torch.relu(self.dense2(x))
        x = self.output(x)
        return x


# 模型训练
def train_model(model, train_loader, test_loader, epochs, device, emotion_labels, learning_rate=0.0005,
                accumulation_steps=2, step=0, continuous_learning_steps=1000):
    criterion = nn.CrossEntropyLoss()  # 使用交叉熵损失函数
    optimizer = optim.Adam(model.parameters(), lr=0.0005)  # 指定学习率
    scaler = GradScaler()
    best_accuracy = 0.0

    model_dir = "models"
    os.makedirs(model_dir, exist_ok=True)  # 创建目录,如果目录不存在

    original_model = model  # 保存原始模型的引用
    model = nn.DataParallel(model)  # 使用DataParallel包装模型
    model = model.to(device)

    metrics_list = []  # 用于存储评估指标的列表

    for epoch in range(epochs):
        model.train()
        train_loader_iter = iter(train_loader)

        batch_idx = 0
        while True:
            try:
                fixed_data, seq_data, target = next(train_loader_iter)
            except StopIteration:
                break

            fixed_data = [feat.to(device) for feat in fixed_data]
            seq_data = [[(feat[0].to(device), feat[1].to(device), feat[2].to(device)) for feat in seq_feat_group]
                        for seq_feat_group in seq_data]
            target = target.to(device)

            optimizer.zero_grad()

            with autocast():
                output = model(fixed_data, seq_data)
                loss = criterion(output, target)
                loss = loss / accumulation_steps  # 将损失除以累积步数

            scaler.scale(loss).backward()

            if (batch_idx + 1) % accumulation_steps == 0:
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

            batch_idx += 1

        model.eval()
        all_predictions = []
        all_targets = []
        with torch.no_grad():
            for fixed_data, seq_data, target in test_loader:
                fixed_data = [feat.to(device) for feat in fixed_data]
                seq_data = [[(feat[0].to(device), feat[1].to(device), feat[2].to(device)) for feat in seq_feat_group]
                            for seq_feat_group in seq_data]
                target = target.to(device)
                output = model(fixed_data, seq_data)
                predicted = torch.argmax(output, dim=1)  # 获取预测类别索引
                if predicted.dim() > 1:
                    predicted = predicted.squeeze()  # 去除多余的维度
                all_predictions.append(predicted.cpu().numpy())
                all_targets.append(target.cpu().numpy())

        all_predictions = np.concatenate(all_predictions)
        all_targets = np.concatenate(all_targets)

        # 计算混淆矩阵
        conf_matrix = confusion_matrix(all_targets, all_predictions)
        print("Confusion Matrix:")
        print(conf_matrix)
        # 从混淆矩阵计算F1、recall和precision
        f1 = f1_score(all_targets, all_predictions, average='macro', zero_division=0)
        recall = recall_score(all_targets, all_predictions, average='macro', zero_division=0)
        precision = precision_score(all_targets, all_predictions, average='macro', zero_division=0)

        print(
            f"Continuous Learning Step {step + 1}/{continuous_learning_steps}, Epoch {epoch + 1}/{epochs}, Test F1 Score: {f1:.4f}, Recall: {recall:.4f}, Precision: {precision:.4f}")

        # 计算每种情绪的F1、recall和precision
        f1_per_class = f1_score(all_targets, all_predictions, average=None, zero_division=0)
        recall_per_class = recall_score(all_targets, all_predictions, average=None, zero_division=0)
        precision_per_class = precision_score(all_targets, all_predictions, average=None, zero_division=0)

        for emotion_idx, emotion_label in enumerate(emotion_labels):
            if emotion_idx < len(f1_per_class):
                print(
                    f"Emotion {emotion_label}: F1 Score: {f1_per_class[emotion_idx]:.4f}, Recall: {recall_per_class[emotion_idx]:.4f}, Precision: {precision_per_class[emotion_idx]:.4f}")
            else:
                print(f"Emotion {emotion_label}: No samples in the test set.")

        accuracy = accuracy_score(all_targets, all_predictions)
        emotion_accuracies = []
        for emotion_idx in range(len(emotion_labels)):
            emotion_mask = all_targets == emotion_idx
            if emotion_mask.sum() > 0:
                emotion_accuracy = accuracy_score(all_targets[emotion_mask], all_predictions[emotion_mask])
            else:
                emotion_accuracy = np.nan
            emotion_accuracies.append(emotion_accuracy)
            print(f"Emotion {emotion_labels[emotion_idx]}: Accuracy: {emotion_accuracy:.4f}")
        metrics = {
            'Continuous Learning Step': step + 1,
            'Epoch': epoch + 1,
            'Accuracy': accuracy,
            'F1 Score': f1,
            'Recall': recall,
            'Precision': precision
        }
        for emotion_idx, emotion_label in enumerate(emotion_labels):
            metrics[f'{emotion_label} Accuracy'] = emotion_accuracies[emotion_idx]

        metrics_list.append(metrics)  # 将当前 epoch 的评估指标添加到列表中

        if accuracy > best_accuracy:
            best_accuracy = accuracy
            model_path = os.path.join(model_dir, f"{original_model.name}.pth")  # 使用原始模型的名称
            torch.save(original_model.state_dict(), model_path)  # 保存原始模型的状态字典

        print(f"Best Test Accuracy: {best_accuracy:.4f}")

        metrics_df = pd.DataFrame(metrics_list)  # 将评估指标列表转换为 DataFrame
        print("\nTraining Metrics:")
        print(metrics_df)

        # 将当前批次的数据添加到重放缓冲区中
        replay_buffer.add(fixed_features_batch, sequence_features_batch, labels_batch)

    return original_model, metrics_df  # 返回原始模型和指标数据框


def count_music_groups(data_dir):
    music_ids = set()
    for sub_dir in ['vocals', 'drums', 'bass', 'other']:
        sub_dir_path = os.path.join(data_dir, sub_dir)
        file_list = os.listdir(sub_dir_path)
        for file_name in file_list:
            if file_name.endswith(".wav"):
                music_id = int(file_name[:-4])
                music_ids.add(music_id)
    return len(music_ids)


if __name__ == '__main__':
    data_dir = 'D:/BaiduNetdiskDownload/音轨2'
    csv_file = 'D:/validation.csv'
    emotion_labels = ['Melancholic', 'Fresh', 'Healing', 'Peaceful', 'Exciting', 'Joyful', 'Romantic', 'Nostalgic',
                      'Lonely', 'Relaxing', 'Touching', 'Missing']
    num_emotions = len(emotion_labels)
    num_threads = 256
    epochs = 10
    continuous_learning_steps = 1000
    target_sr = 16000  # 目标采样率
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    total_groups = count_music_groups(data_dir)
    batch_size = total_groups // continuous_learning_steps  # 根据总文件数量和连续学习步数计算每次读取的数量

    replay_buffer = ReplayBuffer(max_size=200)

    all_metrics_df = pd.DataFrame()  # 用于存储所有连续学习步骤的指标
    for step in range(continuous_learning_steps):
        print(f"Continuous Learning Step {step + 1}/{continuous_learning_steps}")

        start_index = step * batch_size
        end_index = (step + 1) * batch_size if step < continuous_learning_steps - 1 else total_groups

        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            print(f"Using {num_threads} threads for data loading.")

            futures = []
            chunk_size = (end_index - start_index) // num_threads
            for i in range(num_threads):
                sub_start_index = start_index + i * chunk_size
                sub_end_index = start_index + (i + 1) * chunk_size if i < num_threads - 1 else end_index
                futures.append(
                    executor.submit(load_data, data_dir, csv_file, sub_start_index, sub_end_index, target_sr))

            fixed_features_batch = []
            sequence_features_batch = []
            labels_batch = []

            for future in futures:
                fixed_features_batch_part, sequence_features_batch_part, labels_batch_part = future.result()
                fixed_features_batch.extend(fixed_features_batch_part)
                sequence_features_batch.extend(sequence_features_batch_part)
                labels_batch.extend(labels_batch_part)

        print("Data loading completed.")

        # 将情绪标签转换为数字编码
        label_to_idx = {label: idx for idx, label in enumerate(emotion_labels)}
        labels_batch = [label_to_idx[label] for label in labels_batch]

        train_fixed_features, test_fixed_features, train_sequence_features, test_sequence_features, train_labels, test_labels = train_test_split(
            fixed_features_batch, sequence_features_batch, labels_batch, test_size=0.2, random_state=42)

        if step > 0:
            replay_data = replay_buffer.sample(batch_size)
            if replay_data is not None:
                replay_fixed_features, replay_sequence_features, replay_labels = replay_data
                train_fixed_features.extend(replay_fixed_features)
                train_sequence_features.extend(replay_sequence_features)
                train_labels.extend(replay_labels)

        train_dataset = MyDataset(train_fixed_features, train_sequence_features, train_labels)
        test_dataset = MyDataset(test_fixed_features, test_sequence_features, test_labels)
        train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True, collate_fn=collate_fn)
        test_loader = DataLoader(test_dataset, batch_size=16, collate_fn=collate_fn)

        if step == 0:
            model = MultiModalAttentionModel(4, num_emotions, name='MultiModalAttentionModel').to(device)
        else:
            model = MultiModalAttentionModel(4, num_emotions, name='MultiModalAttentionModel').to(device)
            model.load_state_dict(torch.load('models/MultiModalAttentionModel.pth'))

        # 训练模型并获取指标
        model, step_metrics_df = train_model(model, train_loader, test_loader, epochs, device, emotion_labels,
                                             learning_rate=0.0005, accumulation_steps=2, step=step,
                                             continuous_learning_steps=continuous_learning_steps)

        # 将当前步骤的指标添加到总表格中
        all_metrics_df = pd.concat([all_metrics_df, step_metrics_df], ignore_index=True)

    # 将总表格保存为 CSV 文件
    all_metrics_df.to_csv(f"{model.name}_training_metrics.csv", index=False)