import pandas as pd


def sample_by_label_count(source_csv_path, target_csv_path, output_path):
    # 读取源CSV文件，计算每个label的数量
    source_df = pd.read_csv(source_csv_path)
    label_counts = source_df['label'].value_counts()

    # 读取目标CSV文件
    target_df = pd.read_csv(target_csv_path)

    # 创建一个空的DataFrame来存储最终结果
    sampled_df = pd.DataFrame()

    # 对于源数据中的每个label及其数量，从目标数据中抽取相同数量的行
    for label, count in label_counts.items():
        # 筛选出目标数据中相同label的行，并随机抽取相应数量的行
        matching_rows = target_df[target_df['label'] == label].sample(
            n=min(len(target_df[target_df['label'] == label]), count), random_state=1)
        sampled_df = pd.concat([sampled_df, matching_rows], ignore_index=True)

    # 保存结果到新的CSV文件
    sampled_df.to_csv(output_path, index=False)
    print(f"已根据 {source_csv_path} 中的label数量，从 {target_csv_path} 中抽取数据并保存到 {output_path}")


if __name__ == '__main__':
    source_csv_path = "C:\\Users\shuoz\Desktop\\failed_downloads.csv"  # 源CSV文件路径，用于计算每个label的数量
    target_csv_path = "C:\\Users\shuoz\Desktop\网易云\output_table.csv"  # 目标CSV文件路径，用于根据label数量进行抽样
    output_path = 'C:\\Users\shuoz\Desktop\网易云\output table.csv'  # 输出结果的CSV文件路径
    sample_by_label_count(source_csv_path, target_csv_path, output_path)
