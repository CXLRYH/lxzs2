import os
import numpy as np
import librosa
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score, confusion_matrix
from sklearn.utils import resample
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from concurrent.futures import ThreadPoolExecutor
from torch.cuda.amp import autocast, GradScaler
from tqdm import tqdm

# 自定义Dataset类
class MyDataset(Dataset):
    def __init__(self, fixed_features, sequence_features, labels):
        self.fixed_features = fixed_features
        self.sequence_features = sequence_features
        self.labels = labels

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        fixed_feature = torch.from_numpy(self.fixed_features[idx]).float()
        mfcc_feat, rolloff_feat, chroma_feat = self.sequence_features[idx]
        mfcc_feat = torch.from_numpy(mfcc_feat).float()
        rolloff_feat = torch.from_numpy(rolloff_feat).float()
        chroma_feat = torch.from_numpy(chroma_feat).float()
        label = self.labels[idx]

        return fixed_feature, (mfcc_feat, rolloff_feat, chroma_feat), label

# 数据准备
def load_data(data_dir, csv_file, start_index, end_index, target_sr=160000, target_samples_per_class=1000, max_seq_length=1000):
    df = pd.read_csv(csv_file)

    # 根据文件名生成字典
    file_dict = {}
    for sub_dir in ['vocals', 'drums', 'bass', 'other']:
        sub_dir_path = os.path.join(data_dir, sub_dir)
        file_list = os.listdir(sub_dir_path)
        for file_name in file_list:
            if file_name.endswith(".wav"):
                music_id = int(file_name[:-4])
                if music_id not in file_dict:
                    file_dict[music_id] = {}
                file_dict[music_id][sub_dir] = file_name

    # 匹配 CSV 文件中的标签
    fixed_features = []
    sequence_features = []
    labels = []
    emotion_samples = {emotion: [] for emotion in emotion_labels}
    for music_id, file_names in tqdm(list(file_dict.items())[start_index:end_index], desc="Extracting features"):
        label = df.loc[df['id'] == music_id, 'label'].values
        if len(label) > 0:
            label = label[0]
            for sub_dir in ['vocals', 'drums', 'bass', 'other']:
                file_path = os.path.join(data_dir, sub_dir, file_names[sub_dir])
                waveform, sr = librosa.load(file_path, sr=target_sr)

                # 提取特征
                pitches, magnitudes = librosa.piptrack(y=waveform, sr=sr)
                pitch = np.mean(pitches)  # 平均音高
                loudness = np.mean(librosa.amplitude_to_db(magnitudes))  # 响度
                pitch_changes = np.mean(np.diff(pitches))  # 音高变化
                tuning = librosa.estimate_tuning(y=waveform, sr=sr)  # 调性
                key = tuning  # 以Hz为单位表示的调性

                # 固定属性特征
                fixed_feature_group = [pitch, loudness, pitch_changes, key]

                # 序列特征
                mfcc = librosa.feature.mfcc(y=waveform, sr=sr, n_mfcc=10)
                rolloff = librosa.feature.spectral_rolloff(y=waveform, sr=sr)  # 声谱滚降点
                chroma = librosa.feature.chroma_stft(y=waveform, sr=sr)  # 色度频率

                # 对时间维度进行截断或填充,使得所有特征数组的时间长度一致
                pad_width_mfcc = max(0, max_seq_length - mfcc.shape[1])
                pad_width_rolloff = max(0, max_seq_length - rolloff.shape[1])
                pad_width_chroma = max(0, max_seq_length - chroma.shape[1])

                mfcc_padded = np.pad(mfcc, ((0, 0), (0, pad_width_mfcc)), 'constant')[:, :max_seq_length]
                rolloff_padded = np.pad(rolloff, ((0, 0), (0, pad_width_rolloff)), 'constant')[:, :max_seq_length]
                chroma_padded = np.pad(chroma, ((0, 0), (0, pad_width_chroma)), 'constant')[:, :max_seq_length]

                if waveform.size > 0:  # 确保音频文件不为空
                    fixed_features.append(np.array(fixed_feature_group))
                    sequence_features.append((mfcc_padded, rolloff_padded, chroma_padded))
                    labels.append(label)
        else:
            print(f"Label not found for music_id: {music_id}")

    # 对每个情绪类别进行随机抽样
    for emotion, samples in emotion_samples.items():
        if len(samples) > target_samples_per_class:
            samples = resample(samples, n_samples=target_samples_per_class, random_state=42)
        for sample in samples:
            fixed_features.append(sample[0])
            sequence_features.append(sample[1])
            labels.append(sample[2])

    return fixed_features, sequence_features, labels

def collate_fn(batch):
    fixed_features, sequence_features, labels = zip(*batch)

    # 填充固定特征
    fixed_features = torch.stack(fixed_features)

    # 填充序列特征
    mfcc_features = [feat[0] for feat in sequence_features]
    rolloff_features = [feat[1] for feat in sequence_features]
    chroma_features = [feat[2] for feat in sequence_features]

    mfcc_features = torch.nn.utils.rnn.pad_sequence(mfcc_features, batch_first=True)
    rolloff_features = torch.nn.utils.rnn.pad_sequence(rolloff_features, batch_first=True)
    chroma_features = torch.nn.utils.rnn.pad_sequence(chroma_features, batch_first=True)

    padded_sequence_features = (mfcc_features, rolloff_features, chroma_features)

    labels = torch.tensor(labels, dtype=torch.long)  # 将labels转换为Tensor,并使用long()转换为整数类型

    return fixed_features, padded_sequence_features, labels

# 模型定义
class TransformerModel(nn.Module):
    def __init__(self, input_dim, num_emotions, name, num_layers=4, num_heads=8, hidden_dim=256, dropout=0.1):
        super(TransformerModel, self).__init__()
        self.name = name
        self.embedding = nn.Linear(input_dim, hidden_dim)
        self.positional_encoding = PositionalEncoding(hidden_dim, dropout)
        encoder_layer = nn.TransformerEncoderLayer(hidden_dim, num_heads, hidden_dim, dropout)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers)
        self.dense = nn.Linear(hidden_dim, num_emotions)

    def forward(self, x):
        x = self.embedding(x)
        x = self.positional_encoding(x)
        x = self.transformer_encoder(x)
        x = x.mean(dim=1)  # 对序列维度取平均
        x = self.dense(x)
        return x

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

# 模型训练
def train_model(model, train_loader, test_loader, epochs, device, emotion_labels, accumulation_steps=16, step=0, continuous_learning_steps=1000):
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.Adam(model.parameters())
    scaler = GradScaler()
    best_accuracy = 0.0

    model_dir = "models"
    os.makedirs(model_dir, exist_ok=True)  # 创建目录,如果目录不存在

    model = nn.DataParallel(model)  # 使用DataParallel包装模型
    model = model.to(device)

    metrics_list = []  # 用于存储评估指标的列表

    for epoch in range(epochs):
        model.train()
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()

            with autocast():
                output = model(data)
                loss = criterion(output, target)
                loss = loss / accumulation_steps  # 将损失除以累积步数

            scaler.scale(loss).backward()

            if (batch_idx + 1) % accumulation_steps == 0:
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

        model.eval()
        with torch.no_grad():
            all_predictions = []
            all_targets = []
            for data, target in test_loader:
                data, target = data.to(device), target.to(device)
                with autocast():
                    output = model(data)
                predicted = torch.sigmoid(output)
                _, predicted_indices = torch.max(predicted, dim=1)
                all_predictions.append(predicted_indices.cpu().numpy())
                all_targets.append(target.cpu().numpy())

            all_predictions = np.concatenate(all_predictions)
            all_targets = np.argmax(np.concatenate(all_targets), axis=1)

            # 计算混淆矩阵
            conf_matrix = confusion_matrix(all_targets, all_predictions)

            # 从混淆矩阵计算F1、recall和precision
            f1 = f1_score(all_targets, all_predictions, average='micro')
            recall = recall_score(all_targets, all_predictions, average='micro')
            precision = precision_score(all_targets, all_predictions, average='micro')

            print(f"Continuous Learning Step {step + 1}/{continuous_learning_steps}, Epoch {epoch + 1}/{epochs}, Test F1 Score: {f1:.4f}, Recall: {recall:.4f}, Precision: {precision:.4f}")

            # 计算每种情绪的F1、recall和precision
            f1_per_class = f1_score(all_targets, all_predictions, average=None)
            recall_per_class = recall_score(all_targets, all_predictions, average=None)
            precision_per_class = precision_score(all_targets, all_predictions, average=None)

            for emotion_idx, emotion_label in enumerate(emotion_labels):
                print(f"Emotion {emotion_label}: F1 Score: {f1_per_class[emotion_idx]:.4f}, Recall: {recall_per_class[emotion_idx]:.4f}, Precision: {precision_per_class[emotion_idx]:.4f}")

            accuracy = accuracy_score(all_targets, all_predictions)
            emotion_accuracies = []
            for emotion_idx in range(len(emotion_labels)):
                emotion_targets = all_targets == emotion_idx
                emotion_predictions = all_predictions == emotion_idx
                emotion_accuracy = accuracy_score(emotion_targets, emotion_predictions)
                emotion_accuracies.append(emotion_accuracy)
                print(f"Emotion {emotion_labels[emotion_idx]}: Accuracy: {emotion_accuracy:.4f}")

            metrics = {
                'Continuous Learning Step': step + 1,
                'Epoch': epoch + 1,
                'Accuracy': accuracy,
                'F1 Score': f1,
                'Recall': recall,
                'Precision': precision
            }
            for emotion_idx, emotion_label in enumerate(emotion_labels):
                metrics[f'{emotion_label} Accuracy'] = emotion_accuracies[emotion_idx]

            metrics_list.append(metrics)  # 将当前 epoch 的评估指标添加到列表中

            if accuracy > best_accuracy:
                best_accuracy = accuracy
                model_path = os.path.join(model_dir, f"{model.module.name}.pth")
                torch.save(model.module.state_dict(), model_path)

    print(f"Best Test Accuracy: {best_accuracy:.4f}")

    metrics_df = pd.DataFrame(metrics_list)  # 将评估指标列表转换为 DataFrame
    print("\nTraining Metrics:")
    print(metrics_df)

    return metrics_df

def count_music_groups(data_dir):
    music_ids = set()
    for sub_dir in ['vocals', 'drums', 'bass', 'other']:
        sub_dir_path = os.path.join(data_dir, sub_dir)
        file_list = os.listdir(sub_dir_path)
        for file_name in file_list:
            if file_name.endswith(".wav"):
                music_id = int(file_name[:-4])
                music_ids.add(music_id)
    return len(music_ids)

if __name__ == '__main__':
    data_dir = 'D:/BaiduNetdiskDownload/音轨2'
    csv_file = 'D:/validation.csv'
    emotion_labels = ['Melancholic', 'Fresh', 'Healing', 'Peaceful', 'Exciting', 'Joyful', 'Romantic', 'Nostalgic',
                      'Lonely', 'Relaxing', 'Touching', 'Missing']
    num_emotions = len(emotion_labels)
    num_threads = 128
    epochs = 5
    continuous_learning_steps = 10
    target_sr = 16000  # 目标采样率
    device_id = [0, 1]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    total_groups = count_music_groups(data_dir)
    batch_size = total_groups // continuous_learning_steps  # 根据总文件数量和连续学习步数计算每次读取的数量

    all_metrics_df = pd.DataFrame()  # 用于存储所有连续学习步骤的指标

    for step in range(continuous_learning_steps):
        print(f"Continuous Learning Step {step + 1}/{continuous_learning_steps}")

        start_index = step * batch_size
        end_index = (step + 1) * batch_size if step < continuous_learning_steps - 1 else total_groups

        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            print(f"Using {num_threads} threads for data loading.")

            futures = []
            chunk_size = (end_index - start_index) // num_threads
            for i in range(num_threads):
                sub_start_index = start_index + i * chunk_size
                sub_end_index = start_index + (i + 1) * chunk_size if i < num_threads - 1 else end_index
                futures.append(executor.submit(load_data, data_dir, csv_file, sub_start_index, sub_end_index, target_sr))

            features = []
            labels = []
            for future in futures:
                features_batch, labels_batch = future.result()
                features.extend(features_batch)
                labels.extend(labels_batch)

        print("Data loading completed.")
        # 将情绪标签转换为独热编码形式
        num_samples = len(labels)
        one_hot_labels = np.zeros((num_samples, num_emotions))
        for i, label in enumerate(labels):
            one_hot_labels[i, emotion_labels.index(label)] = 1

        # 将特征转换为具有相同形状的numpy数组
        max_length = max(feature.shape[0] for feature in features)
        padded_features = np.zeros((num_samples, max_length))
        for i, feature in enumerate(features):
            padded_features[i, :feature.shape[0]] = feature

        train_features, test_features, train_labels, test_labels = train_test_split(
            padded_features, one_hot_labels, test_size=0.2, random_state=42)

        print("Data split completed. Starting model training...")

        train_dataset = TensorDataset(torch.from_numpy(train_features).float(), torch.from_numpy(train_labels).float())
        train_loader = DataLoader(train_dataset, batch_size=2, shuffle=True)
        test_dataset = TensorDataset(torch.from_numpy(test_features).float(), torch.from_numpy(test_labels).float())
        test_loader = DataLoader(test_dataset, batch_size=2)

        input_dim = train_features.shape[1]  # 获取输入特征的维度
        print(f"Input dimension: {input_dim}")
        if step == 0:
            model = TransformerModel(input_dim, num_emotions, name='TransformerModel').to(device)
        else:
            model = TransformerModel(input_dim, num_emotions, name='TransformerModel').to(device)
            model.load_state_dict(torch.load('models/TransformerModel.pth'))

        # 训练模型并获取指标
        step_metrics_df = train_model(model, train_loader, test_loader, epochs, device, emotion_labels, accumulation_steps=16, step=step, continuous_learning_steps=continuous_learning_steps)

        # 将当前步骤的指标添加到总表格中
        all_metrics_df = pd.concat([all_metrics_df, step_metrics_df], ignore_index=True)

    # 将总表格保存为 CSV 文件
    all_metrics_df.to_csv(f"{model.module.name}_training_metrics.csv", index=False)